#!/system/bin/sh
# ===================================================================
#  SHADOW ALL IN ONE  -  late start service
# ===================================================================
SHADOW_MOD=SHADOW_AllInOne
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AllInOne/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
slog "shadow suite active - profile $(sprofile) - $(ls -1 /data/adb/modules 2>/dev/null | grep -c SHADOW_) modules"
