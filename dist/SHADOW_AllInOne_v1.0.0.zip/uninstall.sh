#!/system/bin/sh
# ===================================================================
#  SHADOW ALL IN ONE  -  uninstaller
#  Removes every module of the suite and all of its data.
# ===================================================================
umount /system/etc/hosts 2>/dev/null
for d in /data/adb/modules/SHADOW_*/; do
  [ -d "$d" ] || continue
  id=$(basename "$d")
  [ "$id" = "SHADOW_AllInOne" ] && continue
  rm -rf "$d" 2>/dev/null
done
rm -rf /data/adb/shadow 2>/dev/null
echo "shadow suite removed"
