#!/system/bin/sh
# ===================================================================
#  SHADOW ALL IN ONE  -  post fs data
# ===================================================================
SHADOW_MOD=SHADOW_AllInOne
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AllInOne/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
mkdir -p /data/adb/shadow
[ -f /data/adb/shadow/profile ] || echo "gaming" > /data/adb/shadow/profile
slog "shadow suite booting"
