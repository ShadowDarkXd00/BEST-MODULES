#!/system/bin/sh
# =====================================================================
#  S H A D O W   R U N T I M E   L I B R A R Y      v1.0.0
#  Shared helpers for every SHADOW_* module.
#  Target: Poco M2 Pro (beryllium) | SDM660 | Adreno 512 | Android 9-14
# =====================================================================

SHADOW_DIR=${SHADOW_DIR:-/data/adb/shadow}
SHADOW_LOG="$SHADOW_DIR/shadow.log"
SHADOW_MAXLOG=262144

# ---------------------------------------------------------------- logging
slog() {
  [ -d "$SHADOW_DIR" ] || mkdir -p "$SHADOW_DIR" 2>/dev/null
  echo "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null) [${SHADOW_MOD:-SHADOW}] $*" 2>/dev/null >> "$SHADOW_LOG"
  _sz=$(stat -c %s "$SHADOW_LOG" 2>/dev/null || echo 0)
  if [ "${_sz:-0}" -gt "$SHADOW_MAXLOG" ]; then
    tail -n 400 "$SHADOW_LOG" 2>/dev/null > "$SHADOW_LOG.tmp"
    mv -f "$SHADOW_LOG.tmp" "$SHADOW_LOG" 2>/dev/null
  fi
}

# ------------------------------------------------------------- properties
sresetprop() {
  if [ -x /data/adb/ksu/bin/resetprop ]; then
    /data/adb/ksu/bin/resetprop "$@" >/dev/null 2>&1 && return 0
  fi
  if [ -x /data/adb/magisk/resetprop ]; then
    /data/adb/magisk/resetprop "$@" >/dev/null 2>&1 && return 0
  fi
  if command -v resetprop >/dev/null 2>&1; then
    resetprop "$@" >/dev/null 2>&1 && return 0
  fi
  return 1
}
sprop()   { sresetprop "$@" || setprop "$@" 2>/dev/null; }
sroprop() { sresetprop "$@" || setprop "$@" 2>/dev/null; }
sget()    { getprop "$1" 2>/dev/null; }

# apply a file of key=value lines (used for each module system.prop)
sapplyprops() {
  [ -r "$1" ] || return 1
  while IFS='=' read -r k v; do
    [ -z "$k" ] && continue
    case "$k" in \#*|'') continue ;; esac
    case "$k" in ro.*) sroprop "$k" "$v" ;; *) sprop "$k" "$v" ;; esac
  done < "$1"
  return 0
}

# ------------------------------------------------------------ file access
sfile() {   # path value  -> write only when the node exists
  [ -e "$1" ] || { slog "skip missing: $1"; return 1; }
  if printf '%s\n' "$2" 2>/dev/null > "$1"; then slog "OK   $1 = $2"; return 0; fi
  slog "FAIL $1 (read-only)"; return 1
}
sfilev()  { [ -r "$1" ] && tr -d '\r\n' < "$1" 2>/dev/null; }
sfileval(){ sfilev "$1"; }
sexists() { [ -e "$1" ]; }
smkdir()  { mkdir -p "$1" 2>/dev/null; }

# ------------------------------------------------------------- settings
ssettings() { # namespace key value
  [ $# -ge 3 ] || return 1
  settings put "$1" "$2" "$3" >/dev/null 2>&1 && return 0
  cmd "$1" put "$1" "$2" "$3" >/dev/null 2>&1 && return 0
  return 1
}
ssettingsget() { settings get "$1" "$2" 2>/dev/null; }

# --------------------------------------------------------------- sysctl
ssysctl() { # key value
  _p=$(echo "$1" | tr '.' '/')
  if [ -w "/proc/sys/$_p" ]; then
    printf '%s\n' "$2" 2>/dev/null > "/proc/sys/$_p" && { slog "sysctl $1=$2"; return 0; }
  fi
  if command -v sysctl >/dev/null 2>&1; then
    sysctl -w "$1=$2" >/dev/null 2>&1 && { slog "sysctl $1=$2"; return 0; }
  fi
  slog "skip sysctl $1 (not writable)"; return 1
}

# ------------------------------------------------------- profile gating
# Profiles let one pack serve gaming, battery, balanced and performance
# users.  A module that is not allowed by the active profile exits early.
sprofile() { sfilev "$SHADOW_DIR/profile"; }
sprofile_gate() { # module id
  _id="$1"; _p=$(sprofile)
  [ -d "$SHADOW_DIR/profiles" ] || return 0        # standalone -> always on
  [ -z "$_p" ] && _p=balanced
  if [ -f "$SHADOW_DIR/always_on" ] && grep -qx "$_id" "$SHADOW_DIR/always_on" 2>/dev/null; then
    return 0
  fi
  _l="$SHADOW_DIR/profiles/$_p"
  [ -f "$_l" ] || return 0
  grep -qx "$_id" "$_l" 2>/dev/null
}

# ------------------------------------------------------------------ CPU
scpu_policies() {
  for d in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -d "$d" ] && echo "$d"
  done
}
scpu_set_gov() { # governor
  for p in $(scpu_policies); do sfile "$p/scaling_governor" "$1"; done
}
scpu_set_min() { # khz
  for p in $(scpu_policies); do sfile "$p/scaling_min_freq" "$1"; done
}
scpu_set_max() { # khz
  for p in $(scpu_policies); do sfile "$p/scaling_max_freq" "$1"; done
}
scpu_maxfreq() {
  for p in $(scpu_policies); do
    _m=$(sfilev "$p/cpuinfo_max_freq")
    [ -n "$_m" ] && echo "$_m"
  done | sort -n | tail -n 1
}
scpu_minfreq() {
  for p in $(scpu_policies); do
    _m=$(sfilev "$p/cpuinfo_min_freq")
    [ -n "$_m" ] && echo "$_m"
  done | sort -n | head -n 1
}
scpu_list_freqs() {
  for p in $(scpu_policies); do
    echo "policy $(basename "$p"): $(sfilev "$p/scaling_available_frequencies" | tr ' ' ',')"
  done
}
scpu_boost_lock() {   # pin every core to its own maximum
  for p in $(scpu_policies); do
    _m=$(sfilev "$p/cpuinfo_max_freq")
    [ -n "$_m" ] && sfile "$p/scaling_max_freq" "$_m" && sfile "$p/scaling_min_freq" "$_m"
  done
}
scpu_governors() {
  for p in $(scpu_policies); do
    echo "$(basename "$p"): $(sfilev "$p/scaling_governor") | avail $(sfilev "$p/scaling_available_governors" | tr ' ' ',')"
  done
}

# ------------------------------------------------------------------ GPU
skgsl() { [ -d /sys/class/kgsl/kgsl-3d0 ] && echo /sys/class/kgsl/kgsl-3d0; }
sgpu_maxfreq() {
  g=$(skgsl); [ -n "$g" ] || return 1
  d="$g/devfreq"
  _max=""
  if [ -r "$d/available_frequencies" ]; then
    _max=$(tr ' ' '\n' < "$d/available_frequencies" 2>/dev/null | grep -E '^[0-9]+$' | sort -n | tail -n 1)
  fi
  [ -z "$_max" ] && _max=$(sfilev "$d/max_freq")
  [ -n "$_max" ] && sfile "$d/max_freq" "$_max"
  echo "$_max"
}
sgpu_minfreq() {
  g=$(skgsl); [ -n "$g" ] || return 1
  sfile "$g/devfreq/min_freq" "$1"
}
sgpu_minpwr() { g=$(skgsl); [ -n "$g" ] && sfile "$g/min_pwrlevel" "$1"; }
sgpu_maxpwr() { g=$(skgsl); [ -n "$g" ] && sfile "$g/max_pwrlevel" "$1"; }
sgpu_gov()     { g=$(skgsl); [ -n "$g" ] && sfile "$g/devfreq/governor" "$1"; }
sgpu_forceclk(){ g=$(skgsl); [ -n "$g" ] || return 1
                 sfile "$g/force_clk_on" 1; sfile "$g/force_bus_on" 1; sfile "$g/force_rail_on" 1; }
sgpu_idle()    { g=$(skgsl); [ -n "$g" ] && sfile "$g/idle_timer" "$1"; }
sgpu_busy()    { g=$(skgsl); [ -n "$g" ] && sfilev "$g/gpu_busy_percentage"; }

# -------------------------------------------------------------- thermal
sthermal_zones() {
  for z in /sys/class/thermal/thermal_zone*; do
    [ -d "$z" ] || continue
    echo "$z:$(sfilev "$z/type")"
  done
}
sthermal_raise() { # type-regex new-max-temp
  _re="$1"; _t="$2"
  for z in /sys/class/thermal/thermal_zone*; do
    [ -d "$z" ] || continue
    _ty=$(sfilev "$z/type")
    echo "$_ty" | grep -qiE "$_re" || continue
    for tp in "$z"/trip_point_*_temp; do
      [ -e "$tp" ] || continue
      _c=$(sfilev "$tp")
      case "$_c" in ''|*[!0-9]*) continue ;; esac
      case "$_t"   in ''|*[!0-9]*) continue ;; esac
      [ "$_c" -lt "$_t" ] || continue
      sfile "$tp" "$_t"
    done
  done
}
sthermal_log() {
  echo "--- thermal $(date '+%F %T') ---" >> "$SHADOW_DIR/thermal.log" 2>/dev/null
  for z in /sys/class/thermal/thermal_zone*; do
    [ -d "$z" ] || continue
    echo "$(sfilev "$z/type")=$(sfilev "$z/temp")" >> "$SHADOW_DIR/thermal.log" 2>/dev/null
  done
}

# ---------------------------------------------------------- power supply
spower() { [ -e "/sys/class/power_supply/$1" ] && echo "/sys/class/power_supply/$1"; }
sbatt()  { spower battery; }
# set the charge-current ceiling, auto-detecting uA vs mA units
scharge_current_max() { # milliamps
  b=$(sbatt); [ -n "$b" ] || return 1
  f="$b/constant_charge_current_max"
  [ -e "$f" ] || return 1
  _cur=$(sfilev "$f"); _v="$1"
  case "$_cur" in
    ''|*[!0-9]*) : ;;
    *) [ "$_cur" -gt 100000 ] && _v=$(( $1 * 1000 )) ;;
  esac
  sfile "$f" "$_v"
}
scharge_current_now() {
  b=$(sbatt); [ -n "$b" ] || return 1
  _c=$(sfilev "$b/constant_charge_current")
  _v=$(sfilev "$b/current_now")
  echo "${_c:-$_v}"
}
scharge_voltage_max() { # millivolts
  b=$(sbatt); [ -n "$b" ] || return 1
  f="$b/voltage_max"
  [ -e "$f" ] || return 1
  _cur=$(sfilev "$f"); _v="$1"
  case "$_cur" in
    ''|*[!0-9]*) : ;;
    *) [ "$_cur" -gt 100000 ] && _v=$(( $1 * 1000 )) ;;
  esac
  sfile "$f" "$_v"
}
scharge_voltage_now() {
  b=$(sbatt); [ -n "$b" ] || return 1
  sfilev "$b/voltage_now"
}
# raise the charge current ceiling on every node the kernel exposes
scharge_set_current() { # milliamps
  for f in /sys/class/power_supply/battery/constant_charge_current_max \
           /sys/class/power_supply/battery/charge_current_max \
           /sys/class/power_supply/battery/charge_current \
           /sys/class/power_supply/battery/current_max \
           /sys/class/power_supply/usb/current_max \
           /sys/class/power_supply/ac/current_max; do
    [ -e "$f" ] || continue
    _cur=$(sfilev "$f"); _v="$1"
    case "$_cur" in
      ''|*[!0-9]*) : ;;
      *) [ "$_cur" -gt 100000 ] && _v=$(( $1 * 1000 )) ;;
    esac
    sfile "$f" "$_v"
  done
}
# raise the charge voltage ceiling on every node the kernel exposes
scharge_set_voltage() { # millivolts
  for f in /sys/class/power_supply/battery/voltage_max \
           /sys/class/power_supply/battery/constant_voltage_max \
           /sys/class/power_supply/battery/charge_voltage_max \
           /sys/class/power_supply/battery/voltage_max_now; do
    [ -e "$f" ] || continue
    _cur=$(sfilev "$f"); _v="$1"
    case "$_cur" in
      ''|*[!0-9]*) : ;;
      *) [ "$_cur" -gt 100000 ] && _v=$(( $1 * 1000 )) ;;
    esac
    sfile "$f" "$_v"
  done
}
# kernel charge_control: "fastcharge", "0" (off) or a current in mA
scharge_control() {
  for f in /sys/class/power_supply/usb/charge_control \
           /sys/class/power_supply/battery/charge_control \
           /sys/class/power_supply/wireless/charge_control; do
    [ -e "$f" ] && sfile "$f" "$1"
  done
}
sbattery_level() {
  b=$(sbatt); [ -n "$b" ] || return 1
  _c=$(sfilev "$b/capacity")
  [ -n "$_c" ] && echo "$_c"
}

# --------------------------------------------------------- touch helpers
stouch_devices() {
  for d in /sys/class/input/input*; do
    [ -e "$d" ] || continue
    _n=$(sfilev "$d/device/name" 2>/dev/null)
    [ -z "$_n" ] && _n=$(sfilev "$d/name" 2>/dev/null)
    case "$_n" in
      *touch*|*Touch*|*TOUCH*|*tp_*|*_tp|*synaptics*|*Synaptics*|*goodix*|*Goodix*|*fts*|*FTS*|*hid-touch*|*elants*|*chipone*|*icn*|*byd*|*hx83112*|*nt36*|*capacitive*)
        echo "$d" ;;
    esac
  done
}
stouch_name() {
  _n=$(sfilev "$1/device/name" 2>/dev/null)
  [ -z "$_n" ] && _n=$(sfilev "$1/name" 2>/dev/null)
  echo "$_n"
}
stouch_set() { # attribute value
  for d in $(stouch_devices); do
    for b in "$d" "$d/device"; do
      [ -e "$b/$1" ] && sfile "$b/$1" "$2"
    done
  done
}
stouch_list() {
  for d in $(stouch_devices); do
    echo "== $(stouch_name "$d") ($d)"
    for b in "$d" "$d/device"; do
      [ -d "$b" ] || continue
      for f in "$b"/*; do
        case "$f" in
          *uevent*|*name*|*id*|*abs*|*capabilities*|*phys*|*properties*|*modalias*|*subsystem*|*uniq*) continue ;;
        esac
        [ -f "$f" ] && echo "   $(basename "$f") = $(sfilev "$f")"
      done
    done
  done
}

# ------------------------------------------------------- app / doze tools
spackages() { pm list packages 2>/dev/null | sed 's/^package://'; }
sdeviceidle_whitelist() { # pkg
  dumpsys deviceidle whitelist "+$1" >/dev/null 2>&1
  cmd deviceidle whitelist "+$1" >/dev/null 2>&1
}
sappop_allow() { # pkg op
  cmd appops set "$1" "$2" allow >/dev/null 2>&1
}
sstandby_active() {
  am set-standby-bucket "$1" active >/dev/null 2>&1
}
swait_boot() { # seconds (default 120)
  _n=${1:-120}; _i=0
  while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$_i" -lt "$_n" ]; do
    sleep 2; _i=$(( _i + 2 ))
  done
}

# ------------------------------------------------------------ networking
swifi_ps_off() {
  if command -v iw >/dev/null 2>&1; then
    iw dev wlan0 set power_save off >/dev/null 2>&1
  fi
  ssettings global wifi_scan_throttle_enabled 0
  ssettings global wifi_watchdog_poor_network_test_enabled 0
  ssettings global wifi_watchdog_poor_network_test_interval_ms 300000
}
smobile_data_boost() {
  ssettings global mobile_data_boost 1
  ssettings global mobile_data 1
}

# -------------------------------------------------------------- misc
srandom() { echo $(( $(od -An -N4 -tu4 < /dev/urandom 2>/dev/null || echo 1) % 9 + 1 )); }
sandroid_ver() { sget ro.build.version.sdk; }
sdevice_code() { sget ro.product.device; }
