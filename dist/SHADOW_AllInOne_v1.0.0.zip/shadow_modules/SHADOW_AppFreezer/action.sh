#!/system/bin/sh
# Action button for SHADOW_AppFreezer (Shadow App Freezer)
SHADOW_MOD=SHADOW_AppFreezer
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AppFreezer/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow App Freezer"
echo " Freezes the apps you list in /data/adb/shadow/freeze.list so they stop running in the background. Everything is thawed again when the module is removed."
echo "-----------------------------------------------"
echo " group    : Tools"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_AppFreezer/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_AppFreezer"
  echo " enable  : ksud module enable SHADOW_AppFreezer"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
