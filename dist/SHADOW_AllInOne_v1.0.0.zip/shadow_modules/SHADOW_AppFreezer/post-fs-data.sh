#!/system/bin/sh
# ===================================================================
#  Shadow App Freezer
#  Freezes the apps you list in /data/adb/shadow/freeze.list so they stop running in the background. Everything is thawed again when the module is removed.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_AppFreezer
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AppFreezer/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AppFreezer/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
exit 0
