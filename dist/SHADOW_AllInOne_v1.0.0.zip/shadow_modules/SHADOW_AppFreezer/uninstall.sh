#!/system/bin/sh
# uninstall SHADOW_AppFreezer
SHADOW_MOD=SHADOW_AppFreezer
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"
if [ -f /data/adb/shadow/freeze.list ]; then
  while read -r p; do
    [ -z "$p" ] && continue
    cmd package un-suspend --user 0 $p >/dev/null 2>&1
  done < /data/adb/shadow/freeze.list
fi
exit 0
