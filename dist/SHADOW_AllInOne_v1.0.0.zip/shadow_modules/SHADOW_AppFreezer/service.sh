#!/system/bin/sh
# ===================================================================
#  Shadow App Freezer  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_AppFreezer
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AppFreezer/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AppFreezer/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
if [ -f /data/adb/shadow/freeze.list ]; then
  while read -r p; do
    [ -z "$p" ] && continue
    case "$p" in \#*) continue ;; esac
    pm path $p >/dev/null 2>&1 || continue
    cmd package suspend --user 0 $p >/dev/null 2>&1 && slog "frozen $p"
  done < /data/adb/shadow/freeze.list
fi
exit 0
