#!/system/bin/sh
# ===================================================================
#  Shadow Animation Speed
#  Speeds every system animation up so the interface reacts instantly on the custom ROM.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_AnimationSpeed
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AnimationSpeed/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AnimationSpeed/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global window_animation_scale 0.5
ssettings global transition_animation_scale 0.5
ssettings global animator_duration_scale 0.5
exit 0
