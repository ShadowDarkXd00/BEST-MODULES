#!/system/bin/sh
# Action button for SHADOW_AnimationSpeed (Shadow Animation Speed)
SHADOW_MOD=SHADOW_AnimationSpeed
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AnimationSpeed/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Animation Speed"
echo " Speeds every system animation up so the interface reacts instantly on the custom ROM."
echo "-----------------------------------------------"
echo " group    : System"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_AnimationSpeed/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_AnimationSpeed"
  echo " enable  : ksud module enable SHADOW_AnimationSpeed"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
