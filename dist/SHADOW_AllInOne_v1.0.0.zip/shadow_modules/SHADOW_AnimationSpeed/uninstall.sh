#!/system/bin/sh
# uninstall SHADOW_AnimationSpeed
SHADOW_MOD=SHADOW_AnimationSpeed
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
