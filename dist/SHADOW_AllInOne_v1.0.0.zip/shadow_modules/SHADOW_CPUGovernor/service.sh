#!/system/bin/sh
# ===================================================================
#  Shadow CPU Governor Switch  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_CPUGovernor
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUGovernor/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUGovernor/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
echo "Switch with: sh /data/adb/shadow/control.sh governor performance|schedutil|powersave"
exit 0
