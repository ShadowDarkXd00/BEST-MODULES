#!/system/bin/sh
# Action button for SHADOW_CPUGovernor (Shadow CPU Governor Switch)
SHADOW_MOD=SHADOW_CPUGovernor
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUGovernor/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Governor Switch"
echo " Switches the CPU governor between performance, schedutil and powersave from the action button without reinstalling anything."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUGovernor/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUGovernor"
  echo " enable  : ksud module enable SHADOW_CPUGovernor"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
