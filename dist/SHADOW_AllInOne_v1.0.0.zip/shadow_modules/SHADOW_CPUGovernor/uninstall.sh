#!/system/bin/sh
# uninstall SHADOW_CPUGovernor
SHADOW_MOD=SHADOW_CPUGovernor
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
