#!/system/bin/sh
# ===================================================================
#  Shadow CPU Governor Switch
#  Switches the CPU governor between performance, schedutil and powersave from the action button without reinstalling anything.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_CPUGovernor
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUGovernor/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUGovernor/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for p in $(scpu_policies); do
  _av=$(sfilev "$p/scaling_available_governors")
  case "$_av" in
    *schedutil*) sfile "$p/scaling_governor" schedutil ;;
  esac
done
exit 0
