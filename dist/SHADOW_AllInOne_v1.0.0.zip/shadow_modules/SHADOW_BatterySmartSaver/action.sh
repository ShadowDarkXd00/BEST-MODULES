#!/system/bin/sh
# Action button for SHADOW_BatterySmartSaver (Shadow Smart Battery Saver)
SHADOW_MOD=SHADOW_BatterySmartSaver
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatterySmartSaver/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Smart Battery Saver"
echo " Smart saver: switches low power mode on by itself when the battery falls under 20 percent and switches it back off once the phone is charged above 40 percent."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_BatterySmartSaver/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BatterySmartSaver"
  echo " enable  : ksud module enable SHADOW_BatterySmartSaver"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
