#!/system/bin/sh
# uninstall SHADOW_BatterySmartSaver
SHADOW_MOD=SHADOW_BatterySmartSaver
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
