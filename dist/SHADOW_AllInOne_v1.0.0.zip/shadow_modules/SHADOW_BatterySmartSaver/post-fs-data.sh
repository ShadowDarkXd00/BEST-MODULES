#!/system/bin/sh
# ===================================================================
#  Shadow Smart Battery Saver
#  Smart saver: switches low power mode on by itself when the battery falls under 20 percent and switches it back off once the phone is charged above 40 percent.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_BatterySmartSaver
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatterySmartSaver/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BatterySmartSaver/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
( i=0; while [ $i -lt 5000 ]; do
  _lvl=$(sbattery_level)
  case "$_lvl" in
    ''|*[!0-9]*) : ;;
    0|1[0-9]) ssettings global low_power 1 ;;
    4[1-9]|5[0-9]|6[0-9]|7[0-9]|8[0-9]|9[0-9]|100) ssettings global low_power 0 ;;
  esac
  sleep 120; i=$((i+1))
done ) >/dev/null 2>&1 &
exit 0
