#!/system/bin/sh
# Action button for SHADOW_DolbyAtmos (Shadow Dolby Atmos)
SHADOW_MOD=SHADOW_DolbyAtmos
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DolbyAtmos/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Dolby Atmos"
echo " Enables the Dolby Atmos and HiFi audio engines on MIUI based custom ROMs so the phone gets the full sound effect pipeline."
echo "-----------------------------------------------"
echo " group    : Audio"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_DolbyAtmos/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_DolbyAtmos"
  echo " enable  : ksud module enable SHADOW_DolbyAtmos"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
