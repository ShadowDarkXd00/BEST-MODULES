#!/system/bin/sh
# ===================================================================
#  Shadow Dolby Atmos
#  Enables the Dolby Atmos and HiFi audio engines on MIUI based custom ROMs so the phone gets the full sound effect pipeline.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_DolbyAtmos
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DolbyAtmos/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DolbyAtmos/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global dolby_atmos_enabled 1
sprop ro.miui.audio.dolby 1
sprop persist.sys.dolby_atmos 1
slog "dolby atmos engine requested"
exit 0
