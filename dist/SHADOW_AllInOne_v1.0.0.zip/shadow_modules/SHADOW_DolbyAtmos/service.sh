#!/system/bin/sh
# ===================================================================
#  Shadow Dolby Atmos  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_DolbyAtmos
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DolbyAtmos/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DolbyAtmos/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
exit 0
