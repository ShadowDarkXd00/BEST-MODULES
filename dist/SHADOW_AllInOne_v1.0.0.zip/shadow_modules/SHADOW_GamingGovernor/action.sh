#!/system/bin/sh
# Action button for SHADOW_GamingGovernor (Shadow Gaming Governor)
SHADOW_MOD=SHADOW_GamingGovernor
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingGovernor/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming Governor"
echo " Selects the best available CPU governor per cluster (performance, else schedutil) and logs the available governor list for later tuning."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingGovernor/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingGovernor"
  echo " enable  : ksud module enable SHADOW_GamingGovernor"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
