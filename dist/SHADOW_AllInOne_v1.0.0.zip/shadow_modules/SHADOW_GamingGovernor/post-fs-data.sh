#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Governor
#  Selects the best available CPU governor per cluster (performance, else schedutil) and logs the available governor list for later tuning.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GamingGovernor
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingGovernor/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingGovernor/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for p in $(scpu_policies); do
  _av=$(sfilev "$p/scaling_available_governors")
  case "$_av" in
    *performance*) sfile "$p/scaling_governor" performance ;;
    *schedutil*)  sfile "$p/scaling_governor" schedutil ;;
    *ondemand*)   sfile "$p/scaling_governor" ondemand ;;
  esac
done
scpu_governors >> "$SHADOW_DIR/cpu.log" 2>/dev/null
exit 0
