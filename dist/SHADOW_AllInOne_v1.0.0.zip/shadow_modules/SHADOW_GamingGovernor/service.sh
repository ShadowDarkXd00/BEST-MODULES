#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Governor  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GamingGovernor
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingGovernor/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingGovernor/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
scpu_governors >> "$SHADOW_DIR/cpu.log" 2>/dev/null
exit 0
