#!/system/bin/sh
# ===================================================================
#  Shadow CPU Frequency Table  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_CPUFreqTable
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUFreqTable/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUFreqTable/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
scpu_list_freqs >> "$SHADOW_DIR/cpu.log" 2>/dev/null
exit 0
