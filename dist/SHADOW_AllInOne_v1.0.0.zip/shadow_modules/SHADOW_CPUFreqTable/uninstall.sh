#!/system/bin/sh
# uninstall SHADOW_CPUFreqTable
SHADOW_MOD=SHADOW_CPUFreqTable
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
