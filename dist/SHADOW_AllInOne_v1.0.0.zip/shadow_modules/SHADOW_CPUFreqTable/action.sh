#!/system/bin/sh
# Action button for SHADOW_CPUFreqTable (Shadow CPU Frequency Table)
SHADOW_MOD=SHADOW_CPUFreqTable
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUFreqTable/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Frequency Table"
echo " Dumps every cluster with its frequency table, governor and limits into cpu.log so you can see exactly what the SoC is doing."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUFreqTable/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUFreqTable"
  echo " enable  : ksud module enable SHADOW_CPUFreqTable"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
