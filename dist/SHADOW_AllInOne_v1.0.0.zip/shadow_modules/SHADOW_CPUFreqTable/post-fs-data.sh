#!/system/bin/sh
# ===================================================================
#  Shadow CPU Frequency Table
#  Dumps every cluster with its frequency table, governor and limits into cpu.log so you can see exactly what the SoC is doing.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_CPUFreqTable
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUFreqTable/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUFreqTable/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scpu_list_freqs >> "$SHADOW_DIR/cpu.log" 2>/dev/null
scpu_governors >> "$SHADOW_DIR/cpu.log" 2>/dev/null
exit 0
