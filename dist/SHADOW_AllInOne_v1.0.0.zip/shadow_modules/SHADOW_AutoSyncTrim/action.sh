#!/system/bin/sh
# Action button for SHADOW_AutoSyncTrim (Shadow Auto Sync Trim)
SHADOW_MOD=SHADOW_AutoSyncTrim
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AutoSyncTrim/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Auto Sync Trim"
echo " Turns the automatic account sync off. Your mail and photos stop syncing in the background and the idle drain disappears."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_AutoSyncTrim/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_AutoSyncTrim"
  echo " enable  : ksud module enable SHADOW_AutoSyncTrim"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
