#!/system/bin/sh
# ===================================================================
#  Shadow Auto Sync Trim
#  Turns the automatic account sync off. Your mail and photos stop syncing in the background and the idle drain disappears.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_AutoSyncTrim
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AutoSyncTrim/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AutoSyncTrim/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global auto_sync 0
slog "auto sync disabled"
exit 0
