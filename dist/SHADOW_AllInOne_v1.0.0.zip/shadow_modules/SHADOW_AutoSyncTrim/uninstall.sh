#!/system/bin/sh
# uninstall SHADOW_AutoSyncTrim
SHADOW_MOD=SHADOW_AutoSyncTrim
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
