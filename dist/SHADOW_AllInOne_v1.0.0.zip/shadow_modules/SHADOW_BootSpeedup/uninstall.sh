#!/system/bin/sh
# uninstall SHADOW_BootSpeedup
SHADOW_MOD=SHADOW_BootSpeedup
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
