#!/system/bin/sh
# ===================================================================
#  Shadow Boot Speedup
#  Skips the boot animation and marks the device as provisioned, so the custom ROM goes straight to the launcher.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_BootSpeedup
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BootSpeedup/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BootSpeedup/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
service call SurfaceFlinger 1029 i32 1 >/dev/null 2>&1
ssettings global device_provisioned 1
ssettings global device_provisioned 1
exit 0
