#!/system/bin/sh
# Action button for SHADOW_BootSpeedup (Shadow Boot Speedup)
SHADOW_MOD=SHADOW_BootSpeedup
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BootSpeedup/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Boot Speedup"
echo " Skips the boot animation and marks the device as provisioned, so the custom ROM goes straight to the launcher."
echo "-----------------------------------------------"
echo " group    : Tools"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_BootSpeedup/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BootSpeedup"
  echo " enable  : ksud module enable SHADOW_BootSpeedup"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
