#!/system/bin/sh
# uninstall SHADOW_BatteryStats
SHADOW_MOD=SHADOW_BatteryStats
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
