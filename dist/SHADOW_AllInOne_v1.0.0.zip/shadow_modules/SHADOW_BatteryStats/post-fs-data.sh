#!/system/bin/sh
# ===================================================================
#  Shadow Battery Stats
#  Dumps the full battery statistics into battery_stats.txt so you can see which app is really eating your charge.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_BatteryStats
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatteryStats/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BatteryStats/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
exit 0
