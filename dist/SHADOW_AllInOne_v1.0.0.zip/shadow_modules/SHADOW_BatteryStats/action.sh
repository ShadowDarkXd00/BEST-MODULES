#!/system/bin/sh
# Action button for SHADOW_BatteryStats (Shadow Battery Stats)
SHADOW_MOD=SHADOW_BatteryStats
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatteryStats/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Battery Stats"
echo " Dumps the full battery statistics into battery_stats.txt so you can see which app is really eating your charge."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_BatteryStats/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BatteryStats"
  echo " enable  : ksud module enable SHADOW_BatteryStats"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
