#!/system/bin/sh
# ===================================================================
#  Shadow Battery Stats  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_BatteryStats
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatteryStats/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BatteryStats/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
dumpsys batterystats > "$SHADOW_DIR/battery_stats.txt" 2>/dev/null
dumpsys battery >> "$SHADOW_DIR/battery_stats.txt" 2>/dev/null
slog "battery stats written to battery_stats.txt"
exit 0
