#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Boost  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GamingBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingBoost/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingBoost/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
sgpu_maxfreq >/dev/null
slog "gaming boost re-applied at boot complete"

sapplyprops /data/adb/modules/SHADOW_GamingBoost/system.prop 2>/dev/null
exit 0
