#!/system/bin/sh
# Action button for SHADOW_GamingBoost (Shadow Gaming Boost)
SHADOW_MOD=SHADOW_GamingBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingBoost/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming Boost"
echo " One tap performance boost: pins the CPU to max, unlocks the Adreno 512 clock and removes GPU idle. Raises average FPS and removes frame drops in heavy titles."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingBoost/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingBoost"
  echo " enable  : ksud module enable SHADOW_GamingBoost"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
