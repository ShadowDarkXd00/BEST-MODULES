#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Boost
#  One tap performance boost: pins the CPU to max, unlocks the Adreno 512 clock and removes GPU idle. Raises average FPS and removes frame drops in heavy titles.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GamingBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingBoost/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingBoost/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scpu_set_gov performance
scpu_boost_lock
sgpu_maxfreq >/dev/null
sgpu_minpwr 0
sgpu_idle 100
slog "gaming boost armed (cpu+gpu)"
exit 0
