#!/system/bin/sh
# uninstall SHADOW_GamingBoost
SHADOW_MOD=SHADOW_GamingBoost
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
