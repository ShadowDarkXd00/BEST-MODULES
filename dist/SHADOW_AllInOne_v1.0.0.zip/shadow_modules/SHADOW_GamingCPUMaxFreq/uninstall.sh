#!/system/bin/sh
# uninstall SHADOW_GamingCPUMaxFreq
SHADOW_MOD=SHADOW_GamingCPUMaxFreq
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
