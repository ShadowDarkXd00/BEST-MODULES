#!/system/bin/sh
# ===================================================================
#  Shadow Gaming CPU Max Freq
#  Locks the maximum CPU frequency to the hardware ceiling (2.2 GHz on SDM660) so the SoC never downclocks under thermal or battery pressure.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GamingCPUMaxFreq
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingCPUMaxFreq/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingCPUMaxFreq/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for p in $(scpu_policies); do
  _m=$(sfilev "$p/cpuinfo_max_freq")
  [ -n "$_m" ] && sfile "$p/scaling_max_freq" "$_m"
done
exit 0
