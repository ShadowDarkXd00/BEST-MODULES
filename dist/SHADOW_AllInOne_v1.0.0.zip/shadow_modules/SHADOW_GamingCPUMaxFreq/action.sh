#!/system/bin/sh
# Action button for SHADOW_GamingCPUMaxFreq (Shadow Gaming CPU Max Freq)
SHADOW_MOD=SHADOW_GamingCPUMaxFreq
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingCPUMaxFreq/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming CPU Max Freq"
echo " Locks the maximum CPU frequency to the hardware ceiling (2.2 GHz on SDM660) so the SoC never downclocks under thermal or battery pressure."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingCPUMaxFreq/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingCPUMaxFreq"
  echo " enable  : ksud module enable SHADOW_GamingCPUMaxFreq"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
