#!/system/bin/sh
# Action button for SHADOW_ColorEnhance (Shadow Color Enhance)
SHADOW_MOD=SHADOW_ColorEnhance
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ColorEnhance/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Color Enhance"
echo " Removes the accessibility colour filters and the washed out display modes that some custom ROMs leave switched on."
echo "-----------------------------------------------"
echo " group    : Display"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ColorEnhance/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ColorEnhance"
  echo " enable  : ksud module enable SHADOW_ColorEnhance"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
