#!/system/bin/sh
# ===================================================================
#  Shadow Color Enhance
#  Removes the accessibility colour filters and the washed out display modes that some custom ROMs leave switched on.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ColorEnhance
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ColorEnhance/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ColorEnhance/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings secure accessibility_display_daltonizer_enabled 0
ssettings secure accessibility_display_daltonizer 0
ssettings system accessibility_display_daltonizer_enabled 0
slog "display colour filters cleared"
exit 0
