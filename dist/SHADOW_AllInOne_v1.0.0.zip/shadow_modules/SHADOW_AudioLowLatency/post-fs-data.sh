#!/system/bin/sh
# ===================================================================
#  Shadow Audio Low Latency
#  Cuts the audio path delay: the system sound effects are switched off and the vendor audio HAL is told to use the fast path.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_AudioLowLatency
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AudioLowLatency/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AudioLowLatency/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings system sound_effects_enabled 0
ssettings secure immersive_mode_confirmations confirmed
sprop persist.vendor.audio.low_latency 1
slog "low latency audio path requested"
exit 0
