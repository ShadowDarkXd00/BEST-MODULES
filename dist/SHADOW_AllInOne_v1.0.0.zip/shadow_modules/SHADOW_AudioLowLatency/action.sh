#!/system/bin/sh
# Action button for SHADOW_AudioLowLatency (Shadow Audio Low Latency)
SHADOW_MOD=SHADOW_AudioLowLatency
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AudioLowLatency/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Audio Low Latency"
echo " Cuts the audio path delay: the system sound effects are switched off and the vendor audio HAL is told to use the fast path."
echo "-----------------------------------------------"
echo " group    : Audio"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_AudioLowLatency/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_AudioLowLatency"
  echo " enable  : ksud module enable SHADOW_AudioLowLatency"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
