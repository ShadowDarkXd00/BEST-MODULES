#!/system/bin/sh
# uninstall SHADOW_ChargeCurrentMax
SHADOW_MOD=SHADOW_ChargeCurrentMax
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
