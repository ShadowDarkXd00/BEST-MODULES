#!/system/bin/sh
# ===================================================================
#  Shadow Charge Current Max
#  Raises the maximum charging current the battery accepts. The helper auto detects whether the kernel expects microamps or milliamps.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_ChargeCurrentMax
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeCurrentMax/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeCurrentMax/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scharge_set_current 3000
exit 0
