#!/system/bin/sh
# Action button for SHADOW_ChargeCurrentMax (Shadow Charge Current Max)
SHADOW_MOD=SHADOW_ChargeCurrentMax
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeCurrentMax/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Charge Current Max"
echo " Raises the maximum charging current the battery accepts. The helper auto detects whether the kernel expects microamps or milliamps."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeCurrentMax/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeCurrentMax"
  echo " enable  : ksud module enable SHADOW_ChargeCurrentMax"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
