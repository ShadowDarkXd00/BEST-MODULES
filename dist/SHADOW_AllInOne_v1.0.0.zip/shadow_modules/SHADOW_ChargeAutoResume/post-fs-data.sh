#!/system/bin/sh
# ===================================================================
#  Shadow Charge Auto Resume
#  Restarts charging automatically when the charger is reconnected and re applies the charge limits after every plug event.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ChargeAutoResume
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeAutoResume/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeAutoResume/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
( i=0; while [ $i -lt 5000 ]; do
  _u=$(sfilev /sys/class/power_supply/usb/online)
  if [ "$_u" = "1" ]; then
    scharge_set_current 3000
  fi
  sleep 120; i=$((i+1))
done ) >/dev/null 2>&1 &
exit 0
