#!/system/bin/sh
# Action button for SHADOW_ChargeAutoResume (Shadow Charge Auto Resume)
SHADOW_MOD=SHADOW_ChargeAutoResume
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeAutoResume/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Charge Auto Resume"
echo " Restarts charging automatically when the charger is reconnected and re applies the charge limits after every plug event."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeAutoResume/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeAutoResume"
  echo " enable  : ksud module enable SHADOW_ChargeAutoResume"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
