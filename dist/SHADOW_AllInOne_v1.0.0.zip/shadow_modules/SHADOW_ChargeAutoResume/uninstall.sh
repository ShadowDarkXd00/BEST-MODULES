#!/system/bin/sh
# uninstall SHADOW_ChargeAutoResume
SHADOW_MOD=SHADOW_ChargeAutoResume
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
