#!/system/bin/sh
# Action button for SHADOW_Conntrack (Shadow Conntrack Booster)
SHADOW_MOD=SHADOW_Conntrack
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_Conntrack/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Conntrack Booster"
echo " Enlarges the connection tracking table and shortens the timeouts so a busy network never runs out of tracked connections."
echo "-----------------------------------------------"
echo " group    : Network"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_Conntrack/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_Conntrack"
  echo " enable  : ksud module enable SHADOW_Conntrack"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
