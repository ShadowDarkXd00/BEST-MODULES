#!/system/bin/sh
# uninstall SHADOW_Conntrack
SHADOW_MOD=SHADOW_Conntrack
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
