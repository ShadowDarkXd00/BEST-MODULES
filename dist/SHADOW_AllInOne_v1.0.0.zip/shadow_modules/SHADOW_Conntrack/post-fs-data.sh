#!/system/bin/sh
# ===================================================================
#  Shadow Conntrack Booster
#  Enlarges the connection tracking table and shortens the timeouts so a busy network never runs out of tracked connections.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_Conntrack
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_Conntrack/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_Conntrack/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssysctl net.netfilter.nf_conntrack_max 65536
ssysctl net.netfilter.nf_conntrack_tcp_timeout_established 120
ssysctl net.netfilter.nf_conntrack_tcp_timeout_time_wait 30
ssysctl net.netfilter.nf_conntrack_udp_timeout 30
exit 0
