#!/system/bin/sh
# ===================================================================
#  Shadow Charge Bypass
#  Uses the kernel charge_control node to keep the phone running from the charger without cycling the battery, which reduces heat and wear.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ChargeBypass
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeBypass/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeBypass/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scharge_control 0
slog "charge bypass requested where supported"
exit 0
