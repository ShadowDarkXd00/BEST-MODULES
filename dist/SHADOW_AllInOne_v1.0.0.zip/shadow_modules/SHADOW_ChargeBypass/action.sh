#!/system/bin/sh
# Action button for SHADOW_ChargeBypass (Shadow Charge Bypass)
SHADOW_MOD=SHADOW_ChargeBypass
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeBypass/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Charge Bypass"
echo " Uses the kernel charge_control node to keep the phone running from the charger without cycling the battery, which reduces heat and wear."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeBypass/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeBypass"
  echo " enable  : ksud module enable SHADOW_ChargeBypass"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
