#!/system/bin/sh
# uninstall SHADOW_ChargeBypass
SHADOW_MOD=SHADOW_ChargeBypass
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
