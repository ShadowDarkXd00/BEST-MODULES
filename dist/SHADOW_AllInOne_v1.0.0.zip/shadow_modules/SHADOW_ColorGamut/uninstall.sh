#!/system/bin/sh
# uninstall SHADOW_ColorGamut
SHADOW_MOD=SHADOW_ColorGamut
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
