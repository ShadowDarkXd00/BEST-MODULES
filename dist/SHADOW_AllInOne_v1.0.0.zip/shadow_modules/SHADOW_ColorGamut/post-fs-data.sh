#!/system/bin/sh
# ===================================================================
#  Shadow Wide Color Gamut
#  Switches the display to the wide colour gamut and the calibrated colour profile when the panel supports it.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ColorGamut
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ColorGamut/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ColorGamut/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings secure display_color_mode 0
ssettings system color_mode 0
sprop persist.sys.display_color_mode 0
slog "wide colour gamut requested"
exit 0
