#!/system/bin/sh
# Action button for SHADOW_ColorGamut (Shadow Wide Color Gamut)
SHADOW_MOD=SHADOW_ColorGamut
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ColorGamut/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Wide Color Gamut"
echo " Switches the display to the wide colour gamut and the calibrated colour profile when the panel supports it."
echo "-----------------------------------------------"
echo " group    : Display"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ColorGamut/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ColorGamut"
  echo " enable  : ksud module enable SHADOW_ColorGamut"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
