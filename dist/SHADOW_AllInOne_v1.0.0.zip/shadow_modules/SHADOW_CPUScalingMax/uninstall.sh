#!/system/bin/sh
# uninstall SHADOW_CPUScalingMax
SHADOW_MOD=SHADOW_CPUScalingMax
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
