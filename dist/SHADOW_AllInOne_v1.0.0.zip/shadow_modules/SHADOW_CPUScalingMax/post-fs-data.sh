#!/system/bin/sh
# ===================================================================
#  Shadow CPU Max Frequency
#  Sets a CPU frequency ceiling that keeps peak clocks but leaves headroom for the modem and the GPS.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_CPUScalingMax
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUScalingMax/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUScalingMax/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for p in $(scpu_policies); do
  _hi=$(sfilev "$p/cpuinfo_max_freq")
  [ -n "$_hi" ] && sfile "$p/scaling_max_freq" "$_hi"
done
exit 0
