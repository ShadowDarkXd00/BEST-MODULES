#!/system/bin/sh
# Action button for SHADOW_CPUScalingMax (Shadow CPU Max Frequency)
SHADOW_MOD=SHADOW_CPUScalingMax
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUScalingMax/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Max Frequency"
echo " Sets a CPU frequency ceiling that keeps peak clocks but leaves headroom for the modem and the GPS."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUScalingMax/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUScalingMax"
  echo " enable  : ksud module enable SHADOW_CPUScalingMax"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
