#!/system/bin/sh
# uninstall SHADOW_GPUGovernor
SHADOW_MOD=SHADOW_GPUGovernor
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
