#!/system/bin/sh
# ===================================================================
#  Shadow GPU Governor
#  Selects the best available KGSL devfreq governor (simple_ondemand, msm-adreno-tg or performance) for your kernel.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_GPUGovernor
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUGovernor/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPUGovernor/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
g=$(skgsl); [ -n "$g" ] || exit 0
_av=$(sfilev "$g/devfreq/available_governors")
case "$_av" in
  *msm-adreno-tg*) sfile "$g/devfreq/governor" msm-adreno-tg ;;
  *simple_ondemand*) sfile "$g/devfreq/governor" simple_ondemand ;;
esac
slog "gpu governor: $(sfilev "$g/devfreq/governor")"
exit 0
