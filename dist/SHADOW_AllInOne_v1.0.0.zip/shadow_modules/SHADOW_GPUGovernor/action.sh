#!/system/bin/sh
# Action button for SHADOW_GPUGovernor (Shadow GPU Governor)
SHADOW_MOD=SHADOW_GPUGovernor
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUGovernor/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow GPU Governor"
echo " Selects the best available KGSL devfreq governor (simple_ondemand, msm-adreno-tg or performance) for your kernel."
echo "-----------------------------------------------"
echo " group    : GPU"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_GPUGovernor/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GPUGovernor"
  echo " enable  : ksud module enable SHADOW_GPUGovernor"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
