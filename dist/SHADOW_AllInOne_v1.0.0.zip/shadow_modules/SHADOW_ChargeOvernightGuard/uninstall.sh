#!/system/bin/sh
# uninstall SHADOW_ChargeOvernightGuard
SHADOW_MOD=SHADOW_ChargeOvernightGuard
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
