#!/system/bin/sh
# Action button for SHADOW_ChargeOvernightGuard (Shadow Overnight Charge Guard)
SHADOW_MOD=SHADOW_ChargeOvernightGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeOvernightGuard/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Overnight Charge Guard"
echo " Stops the phone from sitting at 100 percent all night. Caps the charge level overnight so the pack is not kept full and hot for eight hours."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeOvernightGuard/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeOvernightGuard"
  echo " enable  : ksud module enable SHADOW_ChargeOvernightGuard"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
