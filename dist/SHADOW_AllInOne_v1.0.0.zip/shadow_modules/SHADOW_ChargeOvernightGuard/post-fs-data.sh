#!/system/bin/sh
# ===================================================================
#  Shadow Overnight Charge Guard
#  Stops the phone from sitting at 100 percent all night. Caps the charge level overnight so the pack is not kept full and hot for eight hours.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_ChargeOvernightGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeOvernightGuard/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeOvernightGuard/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sfile /sys/class/power_supply/battery/charge_limit 80
sfile /sys/class/power_supply/battery/charge_limit_end 80
slog "overnight charge limit requested (80%)"
exit 0
