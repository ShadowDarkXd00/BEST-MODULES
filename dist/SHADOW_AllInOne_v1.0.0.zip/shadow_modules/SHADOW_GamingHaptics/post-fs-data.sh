#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Haptics
#  Stronger and more responsive haptics for shooters and racing games: enables haptic feedback and raises the vibration intensity where the ROM exposes it.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GamingHaptics
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingHaptics/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingHaptics/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings system haptic_feedback_enabled 1
ssettings system haptic_feedback_intensity 100
ssettings system vibrate_when_ringing 1
exit 0
