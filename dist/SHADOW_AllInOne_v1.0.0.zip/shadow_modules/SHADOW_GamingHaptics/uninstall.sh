#!/system/bin/sh
# uninstall SHADOW_GamingHaptics
SHADOW_MOD=SHADOW_GamingHaptics
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
