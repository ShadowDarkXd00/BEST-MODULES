#!/system/bin/sh
# Action button for SHADOW_GamingHaptics (Shadow Gaming Haptics)
SHADOW_MOD=SHADOW_GamingHaptics
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingHaptics/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming Haptics"
echo " Stronger and more responsive haptics for shooters and racing games: enables haptic feedback and raises the vibration intensity where the ROM exposes it."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingHaptics/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingHaptics"
  echo " enable  : ksud module enable SHADOW_GamingHaptics"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
