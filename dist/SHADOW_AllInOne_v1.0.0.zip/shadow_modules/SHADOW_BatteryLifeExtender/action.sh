#!/system/bin/sh
# Action button for SHADOW_BatteryLifeExtender (Shadow Battery Life Extender)
SHADOW_MOD=SHADOW_BatteryLifeExtender
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatteryLifeExtender/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Battery Life Extender"
echo " The classic battery life bundle: bigger ZRAM, tuned memory reclaim, no background sync storm, half animations and a warm standby bucket."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_BatteryLifeExtender/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BatteryLifeExtender"
  echo " enable  : ksud module enable SHADOW_BatteryLifeExtender"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
