#!/system/bin/sh
# ===================================================================
#  Shadow Battery Life Extender
#  The classic battery life bundle: bigger ZRAM, tuned memory reclaim, no background sync storm, half animations and a warm standby bucket.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_BatteryLifeExtender
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatteryLifeExtender/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BatteryLifeExtender/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sfile /sys/block/zram0/comp_algorithm zstd
sfile /sys/block/zram0/disksize 2G
ssysctl vm.min_free_kbytes 131072
ssysctl vm.dirty_ratio 10
ssettings global auto_sync 0
ssettings global window_animation_scale 0.5
ssettings global transition_animation_scale 0.5
ssettings global animator_duration_scale 0.5
exit 0
