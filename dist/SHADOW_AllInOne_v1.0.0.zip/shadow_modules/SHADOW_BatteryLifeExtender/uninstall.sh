#!/system/bin/sh
# uninstall SHADOW_BatteryLifeExtender
SHADOW_MOD=SHADOW_BatteryLifeExtender
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
