#!/system/bin/sh
# Action button for SHADOW_FastCharge (Shadow Fast Charge)
SHADOW_MOD=SHADOW_FastCharge
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_FastCharge/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Fast Charge"
echo " The flagship fast charging module: raises the charge current ceiling and the voltage limit, removes the charging thermal cut and asks the charger IC for maximum power."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_FastCharge/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_FastCharge"
  echo " enable  : ksud module enable SHADOW_FastCharge"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
