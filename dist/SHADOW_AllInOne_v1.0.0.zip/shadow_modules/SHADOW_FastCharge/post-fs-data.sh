#!/system/bin/sh
# ===================================================================
#  Shadow Fast Charge
#  The flagship fast charging module: raises the charge current ceiling and the voltage limit, removes the charging thermal cut and asks the charger IC for maximum power.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_FastCharge
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_FastCharge/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_FastCharge/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scharge_set_current 3000
scharge_set_voltage 4400
scharge_control fastcharge
sfile /sys/class/power_supply/battery/charge_full_design 0
slog "fast charge armed: $(scharge_current_now) mA now"
exit 0
