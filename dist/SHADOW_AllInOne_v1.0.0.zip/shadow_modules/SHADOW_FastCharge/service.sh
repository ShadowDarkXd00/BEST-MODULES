#!/system/bin/sh
# ===================================================================
#  Shadow Fast Charge  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_FastCharge
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_FastCharge/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_FastCharge/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
scharge_set_current 3000
scharge_set_voltage 4400

sapplyprops /data/adb/modules/SHADOW_FastCharge/system.prop 2>/dev/null
exit 0
