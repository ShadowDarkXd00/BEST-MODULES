#!/system/bin/sh
# uninstall SHADOW_FastCharge
SHADOW_MOD=SHADOW_FastCharge
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
