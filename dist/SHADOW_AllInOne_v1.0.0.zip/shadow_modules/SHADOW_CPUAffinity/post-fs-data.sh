#!/system/bin/sh
# ===================================================================
#  Shadow CPU Affinity Hint
#  Reports the current CPU affinity and keeps the scheduler from restricting the game process to the little cores.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_CPUAffinity
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUAffinity/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUAffinity/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
slog "affinity: $(taskset -p $$ 2>/dev/null)"
exit 0
