#!/system/bin/sh
# Action button for SHADOW_CPUAffinity (Shadow CPU Affinity Hint)
SHADOW_MOD=SHADOW_CPUAffinity
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUAffinity/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Affinity Hint"
echo " Reports the current CPU affinity and keeps the scheduler from restricting the game process to the little cores."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUAffinity/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUAffinity"
  echo " enable  : ksud module enable SHADOW_CPUAffinity"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
