#!/system/bin/sh
# uninstall SHADOW_CPUAffinity
SHADOW_MOD=SHADOW_CPUAffinity
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
