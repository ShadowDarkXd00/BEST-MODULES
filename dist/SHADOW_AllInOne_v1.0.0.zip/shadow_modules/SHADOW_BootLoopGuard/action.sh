#!/system/bin/sh
# Action button for SHADOW_BootLoopGuard (Shadow Boot Loop Guard)
SHADOW_MOD=SHADOW_BootLoopGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BootLoopGuard/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Boot Loop Guard"
echo " The safety net of the suite. If the device fails to finish booting three times in a row, the risky modules are disabled automatically and the phone comes back on its own."
echo "-----------------------------------------------"
echo " group    : Tools"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_BootLoopGuard/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BootLoopGuard"
  echo " enable  : ksud module enable SHADOW_BootLoopGuard"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
