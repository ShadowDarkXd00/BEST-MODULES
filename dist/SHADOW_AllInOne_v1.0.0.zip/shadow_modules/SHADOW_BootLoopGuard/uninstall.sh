#!/system/bin/sh
# uninstall SHADOW_BootLoopGuard
SHADOW_MOD=SHADOW_BootLoopGuard
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
