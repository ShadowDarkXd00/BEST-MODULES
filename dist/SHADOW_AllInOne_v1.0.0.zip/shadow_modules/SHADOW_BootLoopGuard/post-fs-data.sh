#!/system/bin/sh
# ===================================================================
#  Shadow Boot Loop Guard
#  The safety net of the suite. If the device fails to finish booting three times in a row, the risky modules are disabled automatically and the phone comes back on its own.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_BootLoopGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BootLoopGuard/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BootLoopGuard/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
if [ -f /data/adb/shadow/boot_pending ]; then
  _c=$(sfilev /data/adb/shadow/boot_failures)
  case "$_c" in ''|*[!0-9]*) _c=0 ;; esac
  _c=$(( _c + 1 ))
  echo "$_c" > /data/adb/shadow/boot_failures
  if [ "$_c" -ge 3 ]; then
    for m in SHADOW_FastCharge SHADOW_ChargeCurrentMax SHADOW_ChargeVoltageMax SHADOW_GamingThermalGuard SHADOW_ThermalThrottleOff SHADOW_ThermalZone SHADOW_CoolMode SHADOW_GamingGPUBoost SHADOW_GPUSchedPolicy SHADOW_CPUSchedFeatures SHADOW_CPUIdleStates; do
      touch /data/adb/modules/$m/disable 2>/dev/null
    done
    echo 0 > /data/adb/shadow/boot_failures
    slog "BOOT LOOP DETECTED - risky modules disabled automatically"
  else
    slog "boot did not complete, failure counter = $_c"
  fi
fi
echo pending > /data/adb/shadow/boot_pending
exit 0
