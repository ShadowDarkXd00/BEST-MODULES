#!/system/bin/sh
# ===================================================================
#  Shadow Boot Loop Guard  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_BootLoopGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BootLoopGuard/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BootLoopGuard/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
rm -f /data/adb/shadow/boot_pending 2>/dev/null
exit 0
