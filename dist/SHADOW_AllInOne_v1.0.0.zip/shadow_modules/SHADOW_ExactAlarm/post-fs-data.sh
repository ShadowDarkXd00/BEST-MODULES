#!/system/bin/sh
# ===================================================================
#  Shadow Exact Alarm Rescue
#  Gives the clock, alarm and calendar apps the exact alarm permission so your alarms still ring on time on a locked custom ROM.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ExactAlarm
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ExactAlarm/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ExactAlarm/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
exit 0
