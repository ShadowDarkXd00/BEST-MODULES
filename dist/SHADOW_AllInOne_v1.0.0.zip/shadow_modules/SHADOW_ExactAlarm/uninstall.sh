#!/system/bin/sh
# uninstall SHADOW_ExactAlarm
SHADOW_MOD=SHADOW_ExactAlarm
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
