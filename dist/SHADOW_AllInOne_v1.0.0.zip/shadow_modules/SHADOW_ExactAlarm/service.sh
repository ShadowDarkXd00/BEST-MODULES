#!/system/bin/sh
# ===================================================================
#  Shadow Exact Alarm Rescue  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_ExactAlarm
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ExactAlarm/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ExactAlarm/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
for p in com.android.deskclock com.google.android.deskclock com.android.calendar com.google.android.calendar; do
  pm path $p >/dev/null 2>&1 || continue
  sappop_allow "$p" SCHEDULE_EXACT_ALARM
  sappop_allow "$p" USE_EXACT_ALARM
done
slog "exact alarm permission granted"
exit 0
