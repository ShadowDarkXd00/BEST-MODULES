#!/system/bin/sh
# Action button for SHADOW_ExactAlarm (Shadow Exact Alarm Rescue)
SHADOW_MOD=SHADOW_ExactAlarm
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ExactAlarm/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Exact Alarm Rescue"
echo " Gives the clock, alarm and calendar apps the exact alarm permission so your alarms still ring on time on a locked custom ROM."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ExactAlarm/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ExactAlarm"
  echo " enable  : ksud module enable SHADOW_ExactAlarm"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
