#!/system/bin/sh
# ===================================================================
#  Shadow Gaming FPS Unlock
#  Unlocks the display refresh rate ceiling (60/90/120 Hz) and enables frame rate multiplication on ROMs that support it, so the panel can run above 60 fps.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_GamingFPSUnlock
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingFPSUnlock/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingFPSUnlock/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings system peak_refresh_rate 120
ssettings system min_refresh_rate 120
sprop debug.sf.frame_rate_multiple_fps 1
ssettings global disable_window_blurs 1
exit 0
