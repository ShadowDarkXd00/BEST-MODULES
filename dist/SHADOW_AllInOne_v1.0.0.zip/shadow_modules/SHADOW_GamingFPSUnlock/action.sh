#!/system/bin/sh
# Action button for SHADOW_GamingFPSUnlock (Shadow Gaming FPS Unlock)
SHADOW_MOD=SHADOW_GamingFPSUnlock
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingFPSUnlock/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming FPS Unlock"
echo " Unlocks the display refresh rate ceiling (60/90/120 Hz) and enables frame rate multiplication on ROMs that support it, so the panel can run above 60 fps."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingFPSUnlock/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingFPSUnlock"
  echo " enable  : ksud module enable SHADOW_GamingFPSUnlock"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
