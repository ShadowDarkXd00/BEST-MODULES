#!/system/bin/sh
# uninstall SHADOW_GamingFPSUnlock
SHADOW_MOD=SHADOW_GamingFPSUnlock
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
