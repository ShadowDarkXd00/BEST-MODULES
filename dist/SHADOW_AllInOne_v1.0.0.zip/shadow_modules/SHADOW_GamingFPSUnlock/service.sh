#!/system/bin/sh
# ===================================================================
#  Shadow Gaming FPS Unlock  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GamingFPSUnlock
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingFPSUnlock/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingFPSUnlock/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
ssettings system peak_refresh_rate 120
exit 0
