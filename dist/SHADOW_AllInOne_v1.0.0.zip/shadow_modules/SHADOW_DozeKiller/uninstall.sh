#!/system/bin/sh
# uninstall SHADOW_DozeKiller
SHADOW_MOD=SHADOW_DozeKiller
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
