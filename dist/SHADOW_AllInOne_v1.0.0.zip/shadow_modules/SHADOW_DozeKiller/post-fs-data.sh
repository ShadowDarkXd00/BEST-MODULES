#!/system/bin/sh
# ===================================================================
#  Shadow Doze Killer
#  Keeps Doze in its unforced state and makes sure no system component can push it into deep sleep, so your apps stay exactly where you left them.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_DozeKiller
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DozeKiller/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DozeKiller/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
dumpsys deviceidle unforce >/dev/null 2>&1
cmd deviceidle unforce >/dev/null 2>&1
ssettings global restricted_device_idle_apps 0
exit 0
