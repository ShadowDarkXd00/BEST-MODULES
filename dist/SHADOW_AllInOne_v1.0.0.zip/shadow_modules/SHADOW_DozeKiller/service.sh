#!/system/bin/sh
# ===================================================================
#  Shadow Doze Killer  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_DozeKiller
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DozeKiller/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DozeKiller/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
( i=0; while [ $i -lt 1000 ]; do
  dumpsys deviceidle unforce >/dev/null 2>&1
  sleep 600; i=$((i+1))
done ) >/dev/null 2>&1 &
exit 0
