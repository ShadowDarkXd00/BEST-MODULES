#!/system/bin/sh
# Action button for SHADOW_DozeKiller (Shadow Doze Killer)
SHADOW_MOD=SHADOW_DozeKiller
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DozeKiller/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Doze Killer"
echo " Keeps Doze in its unforced state and makes sure no system component can push it into deep sleep, so your apps stay exactly where you left them."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_DozeKiller/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_DozeKiller"
  echo " enable  : ksud module enable SHADOW_DozeKiller"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
