#!/system/bin/sh
# ===================================================================
#  Shadow CPU Min Frequency  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_CPUScalingMin
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUScalingMin/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUScalingMin/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
exit 0
