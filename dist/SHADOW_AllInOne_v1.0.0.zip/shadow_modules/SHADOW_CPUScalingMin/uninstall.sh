#!/system/bin/sh
# uninstall SHADOW_CPUScalingMin
SHADOW_MOD=SHADOW_CPUScalingMin
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
