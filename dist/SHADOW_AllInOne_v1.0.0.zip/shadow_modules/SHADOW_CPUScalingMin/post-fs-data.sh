#!/system/bin/sh
# ===================================================================
#  Shadow CPU Min Frequency
#  Sets a guaranteed CPU frequency floor so background tasks never stall the foreground app.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_CPUScalingMin
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUScalingMin/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUScalingMin/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for p in $(scpu_policies); do
  _lo=$(sfilev "$p/cpuinfo_min_freq"); _hi=$(sfilev "$p/cpuinfo_max_freq")
  _mid=$(( (_lo + _hi) / 2 ))
  [ -n "$_hi" ] && sfile "$p/scaling_min_freq" "$_mid"
done
exit 0
