#!/system/bin/sh
# Action button for SHADOW_CPUScalingMin (Shadow CPU Min Frequency)
SHADOW_MOD=SHADOW_CPUScalingMin
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUScalingMin/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Min Frequency"
echo " Sets a guaranteed CPU frequency floor so background tasks never stall the foreground app."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUScalingMin/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUScalingMin"
  echo " enable  : ksud module enable SHADOW_CPUScalingMin"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
