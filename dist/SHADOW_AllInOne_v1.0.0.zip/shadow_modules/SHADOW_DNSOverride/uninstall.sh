#!/system/bin/sh
# uninstall SHADOW_DNSOverride
SHADOW_MOD=SHADOW_DNSOverride
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
