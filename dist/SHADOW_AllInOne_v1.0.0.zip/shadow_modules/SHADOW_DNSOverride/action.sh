#!/system/bin/sh
# Action button for SHADOW_DNSOverride (Shadow DNS Override)
SHADOW_MOD=SHADOW_DNSOverride
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DNSOverride/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow DNS Override"
echo " Points the resolver at a fast public DNS resolver with no ads and no logging, for the whole system."
echo "-----------------------------------------------"
echo " group    : Network"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_DNSOverride/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_DNSOverride"
  echo " enable  : ksud module enable SHADOW_DNSOverride"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
