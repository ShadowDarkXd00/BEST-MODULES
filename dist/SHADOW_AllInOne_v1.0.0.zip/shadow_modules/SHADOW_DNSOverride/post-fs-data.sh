#!/system/bin/sh
# ===================================================================
#  Shadow DNS Override
#  Points the resolver at a fast public DNS resolver with no ads and no logging, for the whole system.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_DNSOverride
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DNSOverride/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DNSOverride/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global private_dns_mode 1
ssettings global private_dns_specifier one.one.one.one
slog "DNS override applied"
exit 0
