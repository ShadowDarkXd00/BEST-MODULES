#!/system/bin/sh
# uninstall SHADOW_BackgroundFreeze
SHADOW_MOD=SHADOW_BackgroundFreeze
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
