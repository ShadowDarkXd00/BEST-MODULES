#!/system/bin/sh
# ===================================================================
#  Shadow Background Freeze Release  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_BackgroundFreeze
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BackgroundFreeze/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BackgroundFreeze/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
for p in $(spackages); do
  sappop_allow "$p" RUN_IN_BACKGROUND
  sappop_allow "$p" RUN_ANY_IN_BACKGROUND
done
slog "background restriction released for every package"
exit 0
