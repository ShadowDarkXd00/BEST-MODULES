#!/system/bin/sh
# ===================================================================
#  Shadow Background Freeze Release
#  Releases the background restriction and allows every app to run in the background. This is the second half of the full battery backup.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_BackgroundFreeze
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BackgroundFreeze/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BackgroundFreeze/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global restrict_background 0
ssettings global restricted_device_idle_apps 0
exit 0
