#!/system/bin/sh
# Action button for SHADOW_BackgroundFreeze (Shadow Background Freeze Release)
SHADOW_MOD=SHADOW_BackgroundFreeze
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BackgroundFreeze/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Background Freeze Release"
echo " Releases the background restriction and allows every app to run in the background. This is the second half of the full battery backup."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_BackgroundFreeze/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BackgroundFreeze"
  echo " enable  : ksud module enable SHADOW_BackgroundFreeze"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
