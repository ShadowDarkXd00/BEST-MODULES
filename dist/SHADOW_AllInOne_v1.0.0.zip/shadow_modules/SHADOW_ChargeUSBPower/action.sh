#!/system/bin/sh
# Action button for SHADOW_ChargeUSBPower (Shadow USB Power Delivery)
SHADOW_MOD=SHADOW_ChargeUSBPower
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeUSBPower/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow USB Power Delivery"
echo " Keeps the USB port in fast charge mode and gives the device maximum current over USB-C and the legacy USB port."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeUSBPower/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeUSBPower"
  echo " enable  : ksud module enable SHADOW_ChargeUSBPower"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
