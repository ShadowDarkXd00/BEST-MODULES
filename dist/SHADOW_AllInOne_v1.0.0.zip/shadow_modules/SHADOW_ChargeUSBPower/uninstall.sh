#!/system/bin/sh
# uninstall SHADOW_ChargeUSBPower
SHADOW_MOD=SHADOW_ChargeUSBPower
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
