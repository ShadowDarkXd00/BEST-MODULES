#!/system/bin/sh
# ===================================================================
#  Shadow USB Power Delivery
#  Keeps the USB port in fast charge mode and gives the device maximum current over USB-C and the legacy USB port.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ChargeUSBPower
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeUSBPower/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeUSBPower/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sfile /sys/class/power_supply/usb/charge_control fastcharge
ssettings global usb_charging_enabled 1
slog "usb power delivery tuned"
exit 0
