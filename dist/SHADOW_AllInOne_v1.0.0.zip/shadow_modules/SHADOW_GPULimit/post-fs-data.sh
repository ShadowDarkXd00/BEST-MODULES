#!/system/bin/sh
# ===================================================================
#  Shadow GPU Limit
#  Caps the GPU to a mid frequency. Use it on battery profile to get roughly double the gaming time.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_GPULimit
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPULimit/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPULimit/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
g=$(skgsl); [ -n "$g" ] || exit 0
_f=$(tr ' ' '\n' < "$g/devfreq/available_frequencies" 2>/dev/null | grep -E '^[0-9]+$' | sort -n | sed -n '2p')
[ -n "$_f" ] && sfile "$g/devfreq/max_freq" "$_f"
exit 0
