#!/system/bin/sh
# uninstall SHADOW_GPULimit
SHADOW_MOD=SHADOW_GPULimit
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
