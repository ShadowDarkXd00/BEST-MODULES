#!/system/bin/sh
# ===================================================================
#  Shadow GPU Limit  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GPULimit
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPULimit/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPULimit/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
exit 0
