#!/system/bin/sh
# Action button for SHADOW_GPULimit (Shadow GPU Limit)
SHADOW_MOD=SHADOW_GPULimit
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPULimit/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow GPU Limit"
echo " Caps the GPU to a mid frequency. Use it on battery profile to get roughly double the gaming time."
echo "-----------------------------------------------"
echo " group    : GPU"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_GPULimit/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GPULimit"
  echo " enable  : ksud module enable SHADOW_GPULimit"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
