#!/system/bin/sh
# ===================================================================
#  Shadow Clipboard Guard  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_ClipboardGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ClipboardGuard/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ClipboardGuard/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
exit 0
