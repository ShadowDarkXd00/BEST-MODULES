#!/system/bin/sh
# ===================================================================
#  Shadow Clipboard Guard
#  Turns off the clipboard history and clears the clipboard when the device boots, so nothing sensitive sits in the buffer.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ClipboardGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ClipboardGuard/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ClipboardGuard/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global clipboard_history_enabled 0
ssettings global enable_clipboard_history 0
cmd clipboard clear >/dev/null 2>&1
exit 0
