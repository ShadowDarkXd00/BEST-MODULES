#!/system/bin/sh
# uninstall SHADOW_ClipboardGuard
SHADOW_MOD=SHADOW_ClipboardGuard
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
