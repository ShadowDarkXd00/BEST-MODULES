#!/system/bin/sh
# Action button for SHADOW_ClipboardGuard (Shadow Clipboard Guard)
SHADOW_MOD=SHADOW_ClipboardGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ClipboardGuard/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Clipboard Guard"
echo " Turns off the clipboard history and clears the clipboard when the device boots, so nothing sensitive sits in the buffer."
echo "-----------------------------------------------"
echo " group    : Privacy"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ClipboardGuard/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ClipboardGuard"
  echo " enable  : ksud module enable SHADOW_ClipboardGuard"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
