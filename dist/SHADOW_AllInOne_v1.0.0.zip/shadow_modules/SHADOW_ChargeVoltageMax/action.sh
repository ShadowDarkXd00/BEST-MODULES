#!/system/bin/sh
# Action button for SHADOW_ChargeVoltageMax (Shadow Charge Voltage Max)
SHADOW_MOD=SHADOW_ChargeVoltageMax
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeVoltageMax/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Charge Voltage Max"
echo " Raises the charge voltage ceiling to 4.4 V so the battery fills faster and reaches a higher final level."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeVoltageMax/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeVoltageMax"
  echo " enable  : ksud module enable SHADOW_ChargeVoltageMax"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
