#!/system/bin/sh
# ===================================================================
#  Shadow Charge Voltage Max  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_ChargeVoltageMax
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeVoltageMax/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeVoltageMax/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
scharge_set_voltage 4400
exit 0
