#!/system/bin/sh
# ===================================================================
#  Shadow Charge Voltage Max
#  Raises the charge voltage ceiling to 4.4 V so the battery fills faster and reaches a higher final level.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_ChargeVoltageMax
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeVoltageMax/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeVoltageMax/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scharge_set_voltage 4400
exit 0
