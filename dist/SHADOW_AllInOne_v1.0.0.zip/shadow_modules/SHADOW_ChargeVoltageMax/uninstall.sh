#!/system/bin/sh
# uninstall SHADOW_ChargeVoltageMax
SHADOW_MOD=SHADOW_ChargeVoltageMax
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
