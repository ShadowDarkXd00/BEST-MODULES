#!/system/bin/sh
# ===================================================================
#  Shadow Gaming App Freeze  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GamingAppFreeze
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingAppFreeze/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingAppFreeze/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
for p in com.facebook.katana com.facebook.system com.instagram.android com.twitter.android com.netflix.mediaclient com.google.android.youtube com.amazon.mShop.android.shopping; do
  cmd package un-suspend --user 0 $p >/dev/null 2>&1
done
exit 0
