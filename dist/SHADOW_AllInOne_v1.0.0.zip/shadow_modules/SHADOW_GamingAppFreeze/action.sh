#!/system/bin/sh
# Action button for SHADOW_GamingAppFreeze (Shadow Gaming App Freeze)
SHADOW_MOD=SHADOW_GamingAppFreeze
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingAppFreeze/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming App Freeze"
echo " Suspends the usual battery hogs (social, streaming, shopping apps) while a game is running, then wakes them back up afterwards."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingAppFreeze/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingAppFreeze"
  echo " enable  : ksud module enable SHADOW_GamingAppFreeze"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
