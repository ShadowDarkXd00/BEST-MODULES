#!/system/bin/sh
# uninstall SHADOW_GamingAppFreeze
SHADOW_MOD=SHADOW_GamingAppFreeze
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
