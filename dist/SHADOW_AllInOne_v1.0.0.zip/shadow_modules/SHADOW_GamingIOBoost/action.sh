#!/system/bin/sh
# Action button for SHADOW_GamingIOBoost (Shadow Gaming IO Boost)
SHADOW_MOD=SHADOW_GamingIOBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingIOBoost/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming IO Boost"
echo " Storage tuning: mq-deadline scheduler, larger readahead window, faster writeback and lower dirty page thresholds so textures load without hitches."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingIOBoost/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingIOBoost"
  echo " enable  : ksud module enable SHADOW_GamingIOBoost"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
