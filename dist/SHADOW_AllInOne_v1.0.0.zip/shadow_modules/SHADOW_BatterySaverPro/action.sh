#!/system/bin/sh
# Action button for SHADOW_BatterySaverPro (Shadow Battery Saver Pro)
SHADOW_MOD=SHADOW_BatterySaverPro
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatterySaverPro/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Battery Saver Pro"
echo " Aggressive battery saver: low power mode, powersave CPU governor, small ZRAM and reduced background work. Built for the battery profile."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_BatterySaverPro/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BatterySaverPro"
  echo " enable  : ksud module enable SHADOW_BatterySaverPro"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
