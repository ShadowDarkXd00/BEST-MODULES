#!/system/bin/sh
# uninstall SHADOW_BatterySaverPro
SHADOW_MOD=SHADOW_BatterySaverPro
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
