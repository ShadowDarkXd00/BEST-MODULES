#!/system/bin/sh
# ===================================================================
#  Shadow Battery Saver Pro
#  Aggressive battery saver: low power mode, powersave CPU governor, small ZRAM and reduced background work. Built for the battery profile.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_BatterySaverPro
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatterySaverPro/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BatterySaverPro/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global low_power 1
scpu_set_gov powersave
sfile /sys/block/zram0/disksize 1G
ssysctl vm.min_free_kbytes 131072
ssettings global window_animation_scale 0.5
exit 0
