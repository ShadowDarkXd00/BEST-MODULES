#!/system/bin/sh
# Action button for SHADOW_AppOpsTrim (Shadow App Ops Trim)
SHADOW_MOD=SHADOW_AppOpsTrim
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AppOpsTrim/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow App Ops Trim"
echo " Stops every user app from silently changing your system settings behind your back, while keeping the normal app behaviour untouched."
echo "-----------------------------------------------"
echo " group    : Privacy"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_AppOpsTrim/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_AppOpsTrim"
  echo " enable  : ksud module enable SHADOW_AppOpsTrim"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
