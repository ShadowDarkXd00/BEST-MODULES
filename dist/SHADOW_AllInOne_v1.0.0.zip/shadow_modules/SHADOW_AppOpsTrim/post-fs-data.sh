#!/system/bin/sh
# ===================================================================
#  Shadow App Ops Trim
#  Stops every user app from silently changing your system settings behind your back, while keeping the normal app behaviour untouched.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_AppOpsTrim
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AppOpsTrim/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AppOpsTrim/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
exit 0
