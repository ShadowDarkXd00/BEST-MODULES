#!/system/bin/sh
# uninstall SHADOW_AppOpsTrim
SHADOW_MOD=SHADOW_AppOpsTrim
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
