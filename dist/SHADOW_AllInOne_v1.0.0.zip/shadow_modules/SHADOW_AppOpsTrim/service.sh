#!/system/bin/sh
# ===================================================================
#  Shadow App Ops Trim  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_AppOpsTrim
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AppOpsTrim/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AppOpsTrim/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
for p in $(spackages); do
  case "$p" in com.android.*|android.*) continue ;; esac
  cmd appops set "$p" WRITE_SETTINGS ignore >/dev/null 2>&1
done
slog "write settings appop locked down"
exit 0
