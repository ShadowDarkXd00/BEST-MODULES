#!/system/bin/sh
# uninstall SHADOW_CPUSmoothSwitch
SHADOW_MOD=SHADOW_CPUSmoothSwitch
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
