#!/system/bin/sh
# ===================================================================
#  Shadow CPU Smooth Switching
#  Tunes the big.LITTLE scheduler so the workload moves to the big cores faster and cluster switching stutters disappear.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_CPUSmoothSwitch
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUSmoothSwitch/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUSmoothSwitch/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssysctl kernel.sched_schedstats 0
ssysctl kernel.sched_autogroup_enabled 0
for p in $(scpu_policies); do sfile "$p/sched_boost" 1; done
exit 0
