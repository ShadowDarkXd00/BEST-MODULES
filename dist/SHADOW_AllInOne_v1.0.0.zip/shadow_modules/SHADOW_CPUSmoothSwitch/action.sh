#!/system/bin/sh
# Action button for SHADOW_CPUSmoothSwitch (Shadow CPU Smooth Switching)
SHADOW_MOD=SHADOW_CPUSmoothSwitch
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUSmoothSwitch/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Smooth Switching"
echo " Tunes the big.LITTLE scheduler so the workload moves to the big cores faster and cluster switching stutters disappear."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUSmoothSwitch/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUSmoothSwitch"
  echo " enable  : ksud module enable SHADOW_CPUSmoothSwitch"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
