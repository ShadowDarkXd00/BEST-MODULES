#!/system/bin/sh
# ===================================================================
#  Shadow GPU Busy Watch
#  Logs the Adreno busy percentage so you can see whether the GPU is the bottleneck in a given game.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_GPUBoh
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUBoh/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPUBoh/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
slog "gpu busy = $(sgpu_busy)"
exit 0
