#!/system/bin/sh
# ===================================================================
#  Shadow GPU Busy Watch  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GPUBoh
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUBoh/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPUBoh/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
slog "gpu busy = $(sgpu_busy)"
exit 0
