#!/system/bin/sh
# uninstall SHADOW_GPUBoh
SHADOW_MOD=SHADOW_GPUBoh
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
