#!/system/bin/sh
# Action button for SHADOW_GPUBoh (Shadow GPU Busy Watch)
SHADOW_MOD=SHADOW_GPUBoh
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUBoh/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow GPU Busy Watch"
echo " Logs the Adreno busy percentage so you can see whether the GPU is the bottleneck in a given game."
echo "-----------------------------------------------"
echo " group    : GPU"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_GPUBoh/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GPUBoh"
  echo " enable  : ksud module enable SHADOW_GPUBoh"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
