#!/system/bin/sh
# Action button for SHADOW_GPUMinPwr (Shadow GPU Power Level)
SHADOW_MOD=SHADOW_GPUMinPwr
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUMinPwr/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow GPU Power Level"
echo " Pins the GPU power level to 0 (fastest) so the shader never idles at a low clock between frames."
echo "-----------------------------------------------"
echo " group    : GPU"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GPUMinPwr/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GPUMinPwr"
  echo " enable  : ksud module enable SHADOW_GPUMinPwr"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
