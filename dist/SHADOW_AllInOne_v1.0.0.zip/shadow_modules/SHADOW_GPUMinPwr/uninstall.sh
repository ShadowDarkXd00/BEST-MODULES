#!/system/bin/sh
# uninstall SHADOW_GPUMinPwr
SHADOW_MOD=SHADOW_GPUMinPwr
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
