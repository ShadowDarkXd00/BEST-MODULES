#!/system/bin/sh
# ===================================================================
#  Shadow GPU Power Level
#  Pins the GPU power level to 0 (fastest) so the shader never idles at a low clock between frames.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GPUMinPwr
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUMinPwr/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPUMinPwr/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sgpu_minpwr 0
exit 0
