#!/system/bin/sh
# uninstall SHADOW_GamingAnimSpeed
SHADOW_MOD=SHADOW_GamingAnimSpeed
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
