#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Animation Speed
#  Snappy window, transition and animator scales (0.5x) so menus and app switches feel instant without the full 1x animation stutter.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_GamingAnimSpeed
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingAnimSpeed/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingAnimSpeed/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global window_animation_scale 0.5
ssettings global transition_animation_scale 0.5
ssettings global animator_duration_scale 0.5
exit 0
