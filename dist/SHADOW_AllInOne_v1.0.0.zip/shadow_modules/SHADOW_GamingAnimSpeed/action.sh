#!/system/bin/sh
# Action button for SHADOW_GamingAnimSpeed (Shadow Gaming Animation Speed)
SHADOW_MOD=SHADOW_GamingAnimSpeed
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingAnimSpeed/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming Animation Speed"
echo " Snappy window, transition and animator scales (0.5x) so menus and app switches feel instant without the full 1x animation stutter."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingAnimSpeed/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingAnimSpeed"
  echo " enable  : ksud module enable SHADOW_GamingAnimSpeed"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
