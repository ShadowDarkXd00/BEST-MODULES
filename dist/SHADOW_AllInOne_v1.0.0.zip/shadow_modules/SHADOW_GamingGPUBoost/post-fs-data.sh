#!/system/bin/sh
# ===================================================================
#  Shadow Gaming GPU Boost
#  Full Adreno 512 boost: maximum GPU frequency, minimum power level 0, forced GPU clock and bus, and a short idle timer for zero GPU ramp up delay.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GamingGPUBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingGPUBoost/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingGPUBoost/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sgpu_maxfreq >/dev/null
sgpu_minpwr 0
sgpu_forceclk
sgpu_idle 100
slog "GPU $(sgpu_busy) busy - boosted"
exit 0
