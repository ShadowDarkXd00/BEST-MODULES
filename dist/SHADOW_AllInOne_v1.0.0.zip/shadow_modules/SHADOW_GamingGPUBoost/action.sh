#!/system/bin/sh
# Action button for SHADOW_GamingGPUBoost (Shadow Gaming GPU Boost)
SHADOW_MOD=SHADOW_GamingGPUBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingGPUBoost/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming GPU Boost"
echo " Full Adreno 512 boost: maximum GPU frequency, minimum power level 0, forced GPU clock and bus, and a short idle timer for zero GPU ramp up delay."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingGPUBoost/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingGPUBoost"
  echo " enable  : ksud module enable SHADOW_GamingGPUBoost"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
