#!/system/bin/sh
# ===================================================================
#  Shadow Gaming GPU Boost  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GamingGPUBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingGPUBoost/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingGPUBoost/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
sgpu_maxfreq >/dev/null
sgpu_minpwr 0
exit 0
