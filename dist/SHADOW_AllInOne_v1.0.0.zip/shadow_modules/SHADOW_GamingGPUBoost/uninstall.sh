#!/system/bin/sh
# uninstall SHADOW_GamingGPUBoost
SHADOW_MOD=SHADOW_GamingGPUBoost
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
