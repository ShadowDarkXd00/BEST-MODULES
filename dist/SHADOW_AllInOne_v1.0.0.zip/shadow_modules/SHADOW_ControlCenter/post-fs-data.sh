#!/system/bin/sh
# ===================================================================
#  Shadow Control Center
#  The dashboard of the suite. Shows the battery, the CPU and GPU clocks, the temperatures, the free memory and the state of every installed Shadow module.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ControlCenter
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ControlCenter/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ControlCenter/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
slog "control center ready"
exit 0
