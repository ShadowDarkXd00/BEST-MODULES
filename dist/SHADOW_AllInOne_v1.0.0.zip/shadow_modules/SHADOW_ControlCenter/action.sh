#!/system/bin/sh
# Action button for SHADOW_ControlCenter (Shadow Control Center)
SHADOW_MOD=SHADOW_ControlCenter
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ControlCenter/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Control Center"
echo " The dashboard of the suite. Shows the battery, the CPU and GPU clocks, the temperatures, the free memory and the state of every installed Shadow module."
echo "-----------------------------------------------"
echo " group    : Tools"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ControlCenter/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ControlCenter"
  echo " enable  : ksud module enable SHADOW_ControlCenter"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
echo "==============================================="
echo " SHADOW CONTROL CENTER   profile: $(sprofile)"
echo "==============================================="
echo " battery   : $(sbattery_level)%  $(scharge_voltage_now) mV  $(scharge_current_now) mA"
echo " cpu gov   : $(scpu_governors | tr '\n' ' ')"
echo " gpu       : $(sgpu_busy)% busy  max $(sgpu_maxfreq 2>/dev/null)"
echo " thermal   : $(sthermal_zones | tr '\n' ' ')"
echo " memory    : $(grep MemAvailable /proc/meminfo 2>/dev/null)"
echo " modules   : $(ls -1 /data/adb/modules 2>/dev/null | grep -c SHADOW_) installed"
echo " logs      : /data/adb/shadow/"
echo "==============================================="
