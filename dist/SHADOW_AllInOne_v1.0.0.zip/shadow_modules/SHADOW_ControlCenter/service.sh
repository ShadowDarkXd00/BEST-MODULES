#!/system/bin/sh
# ===================================================================
#  Shadow Control Center  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_ControlCenter
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ControlCenter/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ControlCenter/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
exit 0
