#!/system/bin/sh
# uninstall SHADOW_ControlCenter
SHADOW_MOD=SHADOW_ControlCenter
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
