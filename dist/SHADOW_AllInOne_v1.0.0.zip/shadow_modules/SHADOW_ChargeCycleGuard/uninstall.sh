#!/system/bin/sh
# uninstall SHADOW_ChargeCycleGuard
SHADOW_MOD=SHADOW_ChargeCycleGuard
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
