#!/system/bin/sh
# Action button for SHADOW_ChargeCycleGuard (Shadow Charge Cycle Guard)
SHADOW_MOD=SHADOW_ChargeCycleGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeCycleGuard/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Charge Cycle Guard"
echo " Reduces the number of full charge cycles by keeping the pack in a healthier 40 to 80 percent window on the battery profile."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeCycleGuard/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeCycleGuard"
  echo " enable  : ksud module enable SHADOW_ChargeCycleGuard"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
