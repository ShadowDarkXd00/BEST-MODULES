#!/system/bin/sh
# ===================================================================
#  Shadow Charge Cycle Guard
#  Reduces the number of full charge cycles by keeping the pack in a healthier 40 to 80 percent window on the battery profile.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_ChargeCycleGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeCycleGuard/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeCycleGuard/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sfile /sys/class/power_supply/battery/charge_limit 80
slog "charge cycle guard active"
exit 0
