#!/system/bin/sh
# uninstall SHADOW_BrightnessBoost
SHADOW_MOD=SHADOW_BrightnessBoost
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
