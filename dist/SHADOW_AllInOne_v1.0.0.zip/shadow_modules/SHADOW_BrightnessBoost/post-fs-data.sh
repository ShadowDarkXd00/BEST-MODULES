#!/system/bin/sh
# ===================================================================
#  Shadow Brightness Boost
#  Pushes the backlight to the top of its range and raises the kernel backlight ceiling, with a high quality display mode.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_BrightnessBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BrightnessBoost/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BrightnessBoost/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings system screen_brightness_mode 0
ssettings system screen_brightness 255
ssettings system screen_brightness_float 1.0
for b in /sys/class/backlight/*; do
  [ -e "$b/max_brightness" ] || continue
  sfile "$b/max_brightness" 4095
done
slog "brightness boosted"
exit 0
