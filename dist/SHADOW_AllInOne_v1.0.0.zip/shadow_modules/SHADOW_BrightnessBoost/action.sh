#!/system/bin/sh
# Action button for SHADOW_BrightnessBoost (Shadow Brightness Boost)
SHADOW_MOD=SHADOW_BrightnessBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BrightnessBoost/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Brightness Boost"
echo " Pushes the backlight to the top of its range and raises the kernel backlight ceiling, with a high quality display mode."
echo "-----------------------------------------------"
echo " group    : Display"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_BrightnessBoost/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BrightnessBoost"
  echo " enable  : ksud module enable SHADOW_BrightnessBoost"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
