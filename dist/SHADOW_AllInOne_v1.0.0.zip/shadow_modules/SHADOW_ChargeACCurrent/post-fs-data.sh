#!/system/bin/sh
# ===================================================================
#  Shadow AC Charger Current
#  Uses the full current of a wall charger while keeping the USB port conservative, so the phone charges fastest from the plug.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_ChargeACCurrent
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeACCurrent/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeACCurrent/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sfile /sys/class/power_supply/ac/current_max 3000
sfile /sys/class/power_supply/usb/current_max 1500
exit 0
