#!/system/bin/sh
# Action button for SHADOW_ChargeACCurrent (Shadow AC Charger Current)
SHADOW_MOD=SHADOW_ChargeACCurrent
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeACCurrent/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow AC Charger Current"
echo " Uses the full current of a wall charger while keeping the USB port conservative, so the phone charges fastest from the plug."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeACCurrent/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeACCurrent"
  echo " enable  : ksud module enable SHADOW_ChargeACCurrent"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
