#!/system/bin/sh
# uninstall SHADOW_ChargeACCurrent
SHADOW_MOD=SHADOW_ChargeACCurrent
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
