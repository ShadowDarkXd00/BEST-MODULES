#!/system/bin/sh
# Action button for SHADOW_DarkMode (Shadow Dark Mode)
SHADOW_MOD=SHADOW_DarkMode
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DarkMode/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Dark Mode"
echo " Forces the system wide dark theme and switches the always on dark mode for every app that supports it."
echo "-----------------------------------------------"
echo " group    : System"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_DarkMode/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_DarkMode"
  echo " enable  : ksud module enable SHADOW_DarkMode"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
