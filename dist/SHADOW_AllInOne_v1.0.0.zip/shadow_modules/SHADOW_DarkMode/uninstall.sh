#!/system/bin/sh
# uninstall SHADOW_DarkMode
SHADOW_MOD=SHADOW_DarkMode
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
