#!/system/bin/sh
# ===================================================================
#  Shadow Dark Mode
#  Forces the system wide dark theme and switches the always on dark mode for every app that supports it.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_DarkMode
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DarkMode/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DarkMode/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings secure ui_night_mode 2
cmd uimode night yes >/dev/null 2>&1
slog "dark mode forced"
exit 0
