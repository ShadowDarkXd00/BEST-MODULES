#!/system/bin/sh
# Action button for SHADOW_BatteryHistory (Shadow Battery History)
SHADOW_MOD=SHADOW_BatteryHistory
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatteryHistory/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Battery History"
echo " Records the battery level, temperature, voltage and current every five minutes into battery.log for a full history of your battery."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_BatteryHistory/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BatteryHistory"
  echo " enable  : ksud module enable SHADOW_BatteryHistory"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
