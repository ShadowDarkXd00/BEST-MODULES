#!/system/bin/sh
# uninstall SHADOW_BatteryHistory
SHADOW_MOD=SHADOW_BatteryHistory
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
