#!/system/bin/sh
# ===================================================================
#  Shadow Battery History
#  Records the battery level, temperature, voltage and current every five minutes into battery.log for a full history of your battery.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_BatteryHistory
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BatteryHistory/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BatteryHistory/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
( i=0; while [ $i -lt 5000 ]; do
  echo "$(date '+%F %T') level=$(sbattery_level) temp=$(sfilev /sys/class/power_supply/battery/temp) volt=$(scharge_voltage_now) curr=$(scharge_current_now)" >> "$SHADOW_DIR/battery.log" 2>/dev/null
  sleep 300; i=$((i+1))
done ) >/dev/null 2>&1 &
exit 0
