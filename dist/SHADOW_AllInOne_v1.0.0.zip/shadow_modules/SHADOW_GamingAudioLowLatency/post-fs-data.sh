#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Audio Engine
#  Removes the fullscreen confirmation toast and keeps the audio path awake so game sound starts instantly and is never muted by the system.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_GamingAudioLowLatency
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingAudioLowLatency/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingAudioLowLatency/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings secure immersive_mode_confirmations confirmed
ssettings global low_power 0
sprop persist.vendor.audio.low_latency 1
exit 0
