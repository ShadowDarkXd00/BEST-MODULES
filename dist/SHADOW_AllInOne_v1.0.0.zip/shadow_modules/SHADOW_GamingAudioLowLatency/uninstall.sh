#!/system/bin/sh
# uninstall SHADOW_GamingAudioLowLatency
SHADOW_MOD=SHADOW_GamingAudioLowLatency
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
