#!/system/bin/sh
# Action button for SHADOW_GamingAudioLowLatency (Shadow Gaming Audio Engine)
SHADOW_MOD=SHADOW_GamingAudioLowLatency
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingAudioLowLatency/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming Audio Engine"
echo " Removes the fullscreen confirmation toast and keeps the audio path awake so game sound starts instantly and is never muted by the system."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingAudioLowLatency/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingAudioLowLatency"
  echo " enable  : ksud module enable SHADOW_GamingAudioLowLatency"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
