#!/system/bin/sh
# ===================================================================
#  Shadow Charge Thermal Guard
#  Protects the battery while charging: lowers the charging current when the pack runs hot and blocks charging above a safe temperature.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_ChargeThermalGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeThermalGuard/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeThermalGuard/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sthermal_raise 'battery|charger|usb' 55000
slog "charge thermal guard active"
exit 0
