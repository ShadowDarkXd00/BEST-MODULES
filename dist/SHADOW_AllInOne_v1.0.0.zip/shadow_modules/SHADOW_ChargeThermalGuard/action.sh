#!/system/bin/sh
# Action button for SHADOW_ChargeThermalGuard (Shadow Charge Thermal Guard)
SHADOW_MOD=SHADOW_ChargeThermalGuard
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeThermalGuard/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Charge Thermal Guard"
echo " Protects the battery while charging: lowers the charging current when the pack runs hot and blocks charging above a safe temperature."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeThermalGuard/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeThermalGuard"
  echo " enable  : ksud module enable SHADOW_ChargeThermalGuard"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
