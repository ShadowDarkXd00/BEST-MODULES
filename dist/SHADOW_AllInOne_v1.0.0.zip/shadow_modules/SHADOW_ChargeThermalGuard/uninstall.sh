#!/system/bin/sh
# uninstall SHADOW_ChargeThermalGuard
SHADOW_MOD=SHADOW_ChargeThermalGuard
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
