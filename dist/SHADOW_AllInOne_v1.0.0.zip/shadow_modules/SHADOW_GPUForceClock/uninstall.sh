#!/system/bin/sh
# uninstall SHADOW_GPUForceClock
SHADOW_MOD=SHADOW_GPUForceClock
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
