#!/system/bin/sh
# Action button for SHADOW_GPUForceClock (Shadow GPU Force Clock)
SHADOW_MOD=SHADOW_GPUForceClock
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUForceClock/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow GPU Force Clock"
echo " Forces the GPU clock, bus and rail to stay on. Costs a little battery but removes GPU wake up lag completely."
echo "-----------------------------------------------"
echo " group    : GPU"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GPUForceClock/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GPUForceClock"
  echo " enable  : ksud module enable SHADOW_GPUForceClock"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
