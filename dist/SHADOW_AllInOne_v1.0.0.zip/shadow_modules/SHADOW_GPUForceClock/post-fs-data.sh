#!/system/bin/sh
# ===================================================================
#  Shadow GPU Force Clock
#  Forces the GPU clock, bus and rail to stay on. Costs a little battery but removes GPU wake up lag completely.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GPUForceClock
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUForceClock/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPUForceClock/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sgpu_forceclk
exit 0
