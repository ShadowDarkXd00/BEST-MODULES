#!/system/bin/sh
# ===================================================================
#  Shadow GPU Max Frequency
#  Sets the Adreno 512 to the highest frequency the kernel exposes (up to 850 MHz on beryllium).
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_GPUMaxFreq
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUMaxFreq/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPUMaxFreq/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sgpu_maxfreq >/dev/null
exit 0
