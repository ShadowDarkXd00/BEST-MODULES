#!/system/bin/sh
# Action button for SHADOW_GPUMaxFreq (Shadow GPU Max Frequency)
SHADOW_MOD=SHADOW_GPUMaxFreq
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUMaxFreq/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow GPU Max Frequency"
echo " Sets the Adreno 512 to the highest frequency the kernel exposes (up to 850 MHz on beryllium)."
echo "-----------------------------------------------"
echo " group    : GPU"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_GPUMaxFreq/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GPUMaxFreq"
  echo " enable  : ksud module enable SHADOW_GPUMaxFreq"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
