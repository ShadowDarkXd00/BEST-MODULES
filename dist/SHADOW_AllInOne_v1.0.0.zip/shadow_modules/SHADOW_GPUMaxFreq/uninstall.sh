#!/system/bin/sh
# uninstall SHADOW_GPUMaxFreq
SHADOW_MOD=SHADOW_GPUMaxFreq
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
