#!/system/bin/sh
# ===================================================================
#  Shadow GPU Max Frequency  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GPUMaxFreq
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUMaxFreq/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPUMaxFreq/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
sgpu_maxfreq >/dev/null
exit 0
