#!/system/bin/sh
# Action button for SHADOW_DNSCache (Shadow DNS Cache)
SHADOW_MOD=SHADOW_DNSCache
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DNSCache/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow DNS Cache"
echo " Keeps the DNS resolver warm: enables DNS over TLS, parallel lookups and a longer resolver cache so names resolve instantly."
echo "-----------------------------------------------"
echo " group    : Network"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_DNSCache/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_DNSCache"
  echo " enable  : ksud module enable SHADOW_DNSCache"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
