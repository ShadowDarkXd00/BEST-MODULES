#!/system/bin/sh
# uninstall SHADOW_DNSCache
SHADOW_MOD=SHADOW_DNSCache
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
