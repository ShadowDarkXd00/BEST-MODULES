#!/system/bin/sh
# ===================================================================
#  Shadow DNS Cache
#  Keeps the DNS resolver warm: enables DNS over TLS, parallel lookups and a longer resolver cache so names resolve instantly.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_DNSCache
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DNSCache/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DNSCache/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global private_dns_mode 1
ssettings global private_dns_specifier dns.google
slog "private DNS enabled"
exit 0
