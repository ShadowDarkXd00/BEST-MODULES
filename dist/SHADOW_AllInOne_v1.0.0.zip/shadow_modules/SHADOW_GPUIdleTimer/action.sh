#!/system/bin/sh
# Action button for SHADOW_GPUIdleTimer (Shadow GPU Idle Timer)
SHADOW_MOD=SHADOW_GPUIdleTimer
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUIdleTimer/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow GPU Idle Timer"
echo " Shortens the GPU idle timer so the Adreno returns to full clock almost instantly after a pause."
echo "-----------------------------------------------"
echo " group    : GPU"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GPUIdleTimer/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GPUIdleTimer"
  echo " enable  : ksud module enable SHADOW_GPUIdleTimer"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
