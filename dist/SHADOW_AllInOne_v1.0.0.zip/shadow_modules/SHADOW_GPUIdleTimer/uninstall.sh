#!/system/bin/sh
# uninstall SHADOW_GPUIdleTimer
SHADOW_MOD=SHADOW_GPUIdleTimer
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
