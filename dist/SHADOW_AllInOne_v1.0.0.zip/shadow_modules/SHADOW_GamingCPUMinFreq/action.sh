#!/system/bin/sh
# Action button for SHADOW_GamingCPUMinFreq (Shadow Gaming CPU Min Freq)
SHADOW_MOD=SHADOW_GamingCPUMinFreq
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingCPUMinFreq/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming CPU Min Freq"
echo " Locks the minimum CPU frequency to the hardware maximum so the big cores never downclock during a match. Removes the first seconds of stutter."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingCPUMinFreq/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingCPUMinFreq"
  echo " enable  : ksud module enable SHADOW_GamingCPUMinFreq"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
