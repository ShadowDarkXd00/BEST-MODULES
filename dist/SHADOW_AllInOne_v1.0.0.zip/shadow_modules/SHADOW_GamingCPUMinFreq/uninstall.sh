#!/system/bin/sh
# uninstall SHADOW_GamingCPUMinFreq
SHADOW_MOD=SHADOW_GamingCPUMinFreq
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
