#!/system/bin/sh
# ===================================================================
#  Shadow Gaming CPU Min Freq
#  Locks the minimum CPU frequency to the hardware maximum so the big cores never downclock during a match. Removes the first seconds of stutter.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GamingCPUMinFreq
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingCPUMinFreq/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingCPUMinFreq/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for p in $(scpu_policies); do
  _m=$(sfilev "$p/cpuinfo_max_freq")
  [ -n "$_m" ] && sfile "$p/scaling_min_freq" "$_m"
done
exit 0
