#!/system/bin/sh
# uninstall SHADOW_GPUSchedPolicy
SHADOW_MOD=SHADOW_GPUSchedPolicy
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
