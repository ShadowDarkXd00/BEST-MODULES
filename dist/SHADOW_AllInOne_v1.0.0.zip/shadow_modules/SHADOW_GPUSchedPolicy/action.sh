#!/system/bin/sh
# Action button for SHADOW_GPUSchedPolicy (Shadow GPU Scheduler Policy)
SHADOW_MOD=SHADOW_GPUSchedPolicy
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUSchedPolicy/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow GPU Scheduler Policy"
echo " Applies the Adreno scheduler policy knobs (sched_prio / sched_sigs) where the kernel exposes them."
echo "-----------------------------------------------"
echo " group    : GPU"
echo " profiles : performance,gaming"
echo " status   : $([ -f /data/adb/modules/SHADOW_GPUSchedPolicy/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GPUSchedPolicy"
  echo " enable  : ksud module enable SHADOW_GPUSchedPolicy"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
