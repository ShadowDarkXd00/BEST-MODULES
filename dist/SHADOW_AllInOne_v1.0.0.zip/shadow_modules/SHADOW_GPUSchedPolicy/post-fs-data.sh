#!/system/bin/sh
# ===================================================================
#  Shadow GPU Scheduler Policy
#  Applies the Adreno scheduler policy knobs (sched_prio / sched_sigs) where the kernel exposes them.
#  profile: performance,gaming
# ===================================================================
SHADOW_MOD=SHADOW_GPUSchedPolicy
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GPUSchedPolicy/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GPUSchedPolicy/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
g=$(skgsl)
if [ -n "$g" ]; then
  sfile "$g/sched_prio" 1
  sfile "$g/sched_sigs" 0
fi
exit 0
