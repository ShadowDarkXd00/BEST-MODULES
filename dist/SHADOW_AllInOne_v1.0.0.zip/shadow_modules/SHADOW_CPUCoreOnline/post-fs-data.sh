#!/system/bin/sh
# ===================================================================
#  Shadow CPU Core Online
#  Keeps all CPU cores online (no core parking on the little cluster) which removes the wake up delay of the first interaction.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_CPUCoreOnline
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUCoreOnline/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUCoreOnline/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for c in /sys/devices/system/cpu/cpu[0-9]*/online; do sfile "$c" 1; done
exit 0
