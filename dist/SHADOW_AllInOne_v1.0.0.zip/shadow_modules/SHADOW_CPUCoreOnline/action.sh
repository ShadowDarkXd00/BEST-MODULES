#!/system/bin/sh
# Action button for SHADOW_CPUCoreOnline (Shadow CPU Core Online)
SHADOW_MOD=SHADOW_CPUCoreOnline
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUCoreOnline/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Core Online"
echo " Keeps all CPU cores online (no core parking on the little cluster) which removes the wake up delay of the first interaction."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUCoreOnline/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUCoreOnline"
  echo " enable  : ksud module enable SHADOW_CPUCoreOnline"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
