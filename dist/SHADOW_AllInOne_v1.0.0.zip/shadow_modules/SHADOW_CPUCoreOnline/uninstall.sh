#!/system/bin/sh
# uninstall SHADOW_CPUCoreOnline
SHADOW_MOD=SHADOW_CPUCoreOnline
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
