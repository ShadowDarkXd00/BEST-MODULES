#!/system/bin/sh
# uninstall SHADOW_AdaptiveRefresh
SHADOW_MOD=SHADOW_AdaptiveRefresh
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
