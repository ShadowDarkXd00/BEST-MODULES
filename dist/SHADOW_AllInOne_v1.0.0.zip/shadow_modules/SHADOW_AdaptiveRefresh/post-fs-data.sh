#!/system/bin/sh
# ===================================================================
#  Shadow Adaptive Refresh Rate
#  Lets the panel move between 60 Hz and 120 Hz on its own, which saves battery during menus and uses the full rate while you scroll.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_AdaptiveRefresh
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AdaptiveRefresh/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AdaptiveRefresh/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings system min_refresh_rate 60
ssettings system peak_refresh_rate 120
slog "adaptive refresh enabled"
exit 0
