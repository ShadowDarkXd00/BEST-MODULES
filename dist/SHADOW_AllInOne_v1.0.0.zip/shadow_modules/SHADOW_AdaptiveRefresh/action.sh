#!/system/bin/sh
# Action button for SHADOW_AdaptiveRefresh (Shadow Adaptive Refresh Rate)
SHADOW_MOD=SHADOW_AdaptiveRefresh
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AdaptiveRefresh/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Adaptive Refresh Rate"
echo " Lets the panel move between 60 Hz and 120 Hz on its own, which saves battery during menus and uses the full rate while you scroll."
echo "-----------------------------------------------"
echo " group    : Display"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_AdaptiveRefresh/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_AdaptiveRefresh"
  echo " enable  : ksud module enable SHADOW_AdaptiveRefresh"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
