#!/system/bin/sh
# ===================================================================
#  Shadow Config Backup
#  Backs up the profile and the configuration of the suite to /data/adb/shadow/backup so you can restore it after a reinstall.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ConfigBackup
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ConfigBackup/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ConfigBackup/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
exit 0
