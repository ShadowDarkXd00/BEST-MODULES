#!/system/bin/sh
# Action button for SHADOW_ConfigBackup (Shadow Config Backup)
SHADOW_MOD=SHADOW_ConfigBackup
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ConfigBackup/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Config Backup"
echo " Backs up the profile and the configuration of the suite to /data/adb/shadow/backup so you can restore it after a reinstall."
echo "-----------------------------------------------"
echo " group    : Tools"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ConfigBackup/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ConfigBackup"
  echo " enable  : ksud module enable SHADOW_ConfigBackup"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
