#!/system/bin/sh
# ===================================================================
#  Shadow Config Backup  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_ConfigBackup
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ConfigBackup/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ConfigBackup/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
mkdir -p /data/adb/shadow/backup
cp -f /data/adb/shadow/profile /data/adb/shadow/backup/profile 2>/dev/null
cp -f /data/adb/shadow/always_on /data/adb/shadow/backup/always_on 2>/dev/null
slog "configuration backed up"
exit 0
