#!/system/bin/sh
# uninstall SHADOW_ConfigBackup
SHADOW_MOD=SHADOW_ConfigBackup
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
