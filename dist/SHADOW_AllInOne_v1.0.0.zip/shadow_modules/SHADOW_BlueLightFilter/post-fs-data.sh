#!/system/bin/sh
# ===================================================================
#  Shadow Blue Light Filter
#  Turns on the night light filter with a warm 4200 K colour temperature to protect your eyes in the evening.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_BlueLightFilter
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BlueLightFilter/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BlueLightFilter/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings secure night_display_activated 1
ssettings secure night_display_color_temperature 4200
slog "blue light filter active"
exit 0
