#!/system/bin/sh
# uninstall SHADOW_BlueLightFilter
SHADOW_MOD=SHADOW_BlueLightFilter
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
