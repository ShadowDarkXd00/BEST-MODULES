#!/system/bin/sh
# Action button for SHADOW_BlueLightFilter (Shadow Blue Light Filter)
SHADOW_MOD=SHADOW_BlueLightFilter
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BlueLightFilter/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Blue Light Filter"
echo " Turns on the night light filter with a warm 4200 K colour temperature to protect your eyes in the evening."
echo "-----------------------------------------------"
echo " group    : Display"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_BlueLightFilter/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BlueLightFilter"
  echo " enable  : ksud module enable SHADOW_BlueLightFilter"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
