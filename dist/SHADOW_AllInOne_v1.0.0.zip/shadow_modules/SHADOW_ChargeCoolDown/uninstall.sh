#!/system/bin/sh
# uninstall SHADOW_ChargeCoolDown
SHADOW_MOD=SHADOW_ChargeCoolDown
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
