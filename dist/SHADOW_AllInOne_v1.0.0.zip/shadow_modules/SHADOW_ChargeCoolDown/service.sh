#!/system/bin/sh
# ===================================================================
#  Shadow Charge Cool Down  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_ChargeCoolDown
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeCoolDown/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeCoolDown/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
exit 0
