#!/system/bin/sh
# ===================================================================
#  Shadow Charge Cool Down
#  Charges cooler: reduces the current when the battery is warm so the phone stays comfortable in your hand and the pack ages slower.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_ChargeCoolDown
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeCoolDown/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeCoolDown/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scharge_set_current 1800
sthermal_raise 'battery|shell|skin' 45000
slog "cool charging profile active"
exit 0
