#!/system/bin/sh
# Action button for SHADOW_ChargeCoolDown (Shadow Charge Cool Down)
SHADOW_MOD=SHADOW_ChargeCoolDown
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeCoolDown/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Charge Cool Down"
echo " Charges cooler: reduces the current when the battery is warm so the phone stays comfortable in your hand and the pack ages slower."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeCoolDown/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeCoolDown"
  echo " enable  : ksud module enable SHADOW_ChargeCoolDown"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
