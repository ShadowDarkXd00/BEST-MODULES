#!/system/bin/sh
# uninstall SHADOW_ChargeCurrentLog
SHADOW_MOD=SHADOW_ChargeCurrentLog
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
