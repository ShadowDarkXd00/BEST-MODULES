#!/system/bin/sh
# Action button for SHADOW_ChargeCurrentLog (Shadow Charge Current Log)
SHADOW_MOD=SHADOW_ChargeCurrentLog
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeCurrentLog/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Charge Current Log"
echo " Records the live charge current, voltage and level to charge.log so you can see the real charging speed of your charger."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeCurrentLog/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeCurrentLog"
  echo " enable  : ksud module enable SHADOW_ChargeCurrentLog"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
