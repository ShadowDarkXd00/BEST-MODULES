#!/system/bin/sh
# ===================================================================
#  Shadow Charge Current Log
#  Records the live charge current, voltage and level to charge.log so you can see the real charging speed of your charger.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_ChargeCurrentLog
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeCurrentLog/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeCurrentLog/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
( i=0; while [ $i -lt 5000 ]; do
  echo "$(date '+%F %T') level=$(sbattery_level) current=$(scharge_current_now) voltage=$(scharge_voltage_now)" >> "$SHADOW_DIR/charge.log" 2>/dev/null
  sleep 60; i=$((i+1))
done ) >/dev/null 2>&1 &
exit 0
