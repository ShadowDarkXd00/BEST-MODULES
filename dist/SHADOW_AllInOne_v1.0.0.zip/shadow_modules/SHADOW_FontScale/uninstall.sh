#!/system/bin/sh
# uninstall SHADOW_FontScale
SHADOW_MOD=SHADOW_FontScale
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
