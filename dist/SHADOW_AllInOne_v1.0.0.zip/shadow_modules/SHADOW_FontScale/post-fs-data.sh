#!/system/bin/sh
# ===================================================================
#  Shadow Font Scale
#  Resets the font scale to the default so the system text is never broken by an accidental change.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_FontScale
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_FontScale/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_FontScale/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings system font_scale 1.0
exit 0
