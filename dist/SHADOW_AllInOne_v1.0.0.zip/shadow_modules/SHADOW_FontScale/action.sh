#!/system/bin/sh
# Action button for SHADOW_FontScale (Shadow Font Scale)
SHADOW_MOD=SHADOW_FontScale
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_FontScale/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Font Scale"
echo " Resets the font scale to the default so the system text is never broken by an accidental change."
echo "-----------------------------------------------"
echo " group    : System"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_FontScale/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_FontScale"
  echo " enable  : ksud module enable SHADOW_FontScale"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
