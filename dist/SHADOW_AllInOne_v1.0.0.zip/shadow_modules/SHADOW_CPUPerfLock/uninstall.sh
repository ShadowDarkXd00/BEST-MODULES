#!/system/bin/sh
# uninstall SHADOW_CPUPerfLock
SHADOW_MOD=SHADOW_CPUPerfLock
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
