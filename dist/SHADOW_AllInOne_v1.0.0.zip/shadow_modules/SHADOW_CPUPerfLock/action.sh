#!/system/bin/sh
# Action button for SHADOW_CPUPerfLock (Shadow CPU Performance Lock)
SHADOW_MOD=SHADOW_CPUPerfLock
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUPerfLock/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Performance Lock"
echo " Applies the classic performance lock used by root benchmarks: minimum equals maximum frequency on every policy."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : performance,gaming"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUPerfLock/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUPerfLock"
  echo " enable  : ksud module enable SHADOW_CPUPerfLock"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
