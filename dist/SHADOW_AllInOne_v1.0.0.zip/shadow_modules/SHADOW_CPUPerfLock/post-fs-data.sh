#!/system/bin/sh
# ===================================================================
#  Shadow CPU Performance Lock
#  Applies the classic performance lock used by root benchmarks: minimum equals maximum frequency on every policy.
#  profile: performance,gaming
# ===================================================================
SHADOW_MOD=SHADOW_CPUPerfLock
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUPerfLock/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUPerfLock/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scpu_boost_lock
exit 0
