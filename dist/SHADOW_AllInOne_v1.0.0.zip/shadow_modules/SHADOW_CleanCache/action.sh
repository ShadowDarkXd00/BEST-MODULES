#!/system/bin/sh
# Action button for SHADOW_CleanCache (Shadow Clean Cache)
SHADOW_MOD=SHADOW_CleanCache
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CleanCache/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Clean Cache"
echo " One tap cache cleaner. Trims the application caches and the code cache without touching your personal data."
echo "-----------------------------------------------"
echo " group    : Tools"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_CleanCache/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CleanCache"
  echo " enable  : ksud module enable SHADOW_CleanCache"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
cmd package trim-caches 2G >/dev/null 2>&1
echo " caches trimmed"
