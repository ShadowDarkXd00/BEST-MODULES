#!/system/bin/sh
# uninstall SHADOW_CleanCache
SHADOW_MOD=SHADOW_CleanCache
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
