#!/system/bin/sh
# ===================================================================
#  Shadow Clean Cache  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_CleanCache
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CleanCache/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CleanCache/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
cmd package trim-caches 2G >/dev/null 2>&1
slog "caches trimmed"
exit 0
