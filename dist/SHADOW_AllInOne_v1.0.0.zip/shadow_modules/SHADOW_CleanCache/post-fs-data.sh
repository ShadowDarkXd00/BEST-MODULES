#!/system/bin/sh
# ===================================================================
#  Shadow Clean Cache
#  One tap cache cleaner. Trims the application caches and the code cache without touching your personal data.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_CleanCache
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CleanCache/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CleanCache/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
exit 0
