#!/system/bin/sh
# uninstall SHADOW_BluetoothDrain
SHADOW_MOD=SHADOW_BluetoothDrain
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
