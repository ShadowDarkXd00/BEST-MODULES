#!/system/bin/sh
# ===================================================================
#  Shadow Bluetooth Drain Fix
#  Stops the Bluetooth stack from scanning in the background, which is one of the biggest silent battery drainers on custom ROMs.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_BluetoothDrain
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BluetoothDrain/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_BluetoothDrain/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
ssettings global bluetooth_scan_always_enabled 0
ssettings global bluetooth_max_headset_connections 1
ssettings global bluetooth_address_resolution 0
slog "bluetooth scanning trimmed"
exit 0
