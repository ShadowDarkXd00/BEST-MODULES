#!/system/bin/sh
# Action button for SHADOW_BluetoothDrain (Shadow Bluetooth Drain Fix)
SHADOW_MOD=SHADOW_BluetoothDrain
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_BluetoothDrain/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Bluetooth Drain Fix"
echo " Stops the Bluetooth stack from scanning in the background, which is one of the biggest silent battery drainers on custom ROMs."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_BluetoothDrain/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_BluetoothDrain"
  echo " enable  : ksud module enable SHADOW_BluetoothDrain"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
