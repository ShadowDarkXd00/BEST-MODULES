#!/system/bin/sh
# uninstall SHADOW_CPUBoostConfig
SHADOW_MOD=SHADOW_CPUBoostConfig
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
