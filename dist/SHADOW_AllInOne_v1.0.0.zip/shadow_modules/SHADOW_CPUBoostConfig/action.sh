#!/system/bin/sh
# Action button for SHADOW_CPUBoostConfig (Shadow CPU Boost Config)
SHADOW_MOD=SHADOW_CPUBoostConfig
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUBoostConfig/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Boost Config"
echo " Applies a boost configuration file and the sysfs boost switch so the scheduler can request extra headroom on demand."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : performance,gaming"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUBoostConfig/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUBoostConfig"
  echo " enable  : ksud module enable SHADOW_CPUBoostConfig"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
