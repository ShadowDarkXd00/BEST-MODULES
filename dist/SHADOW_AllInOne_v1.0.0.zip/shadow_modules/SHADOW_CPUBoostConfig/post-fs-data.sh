#!/system/bin/sh
# ===================================================================
#  Shadow CPU Boost Config
#  Applies a boost configuration file and the sysfs boost switch so the scheduler can request extra headroom on demand.
#  profile: performance,gaming
# ===================================================================
SHADOW_MOD=SHADOW_CPUBoostConfig
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUBoostConfig/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUBoostConfig/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sfile /sys/devices/system/cpu/cpufreq/policy0/boost 1
sfile /sys/kernel/mm/boost 1
slog "boost configuration applied"
exit 0
