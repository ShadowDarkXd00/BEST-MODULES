#!/system/bin/sh
# ===================================================================
#  Shadow Doze Policy
#  Profile aware Doze control: Doze stays out of the way while you game, and is pushed back to its most aggressive state on the battery profile.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_DozePolicy
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DozePolicy/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DozePolicy/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
case "$(sprofile)" in
  battery)
    dumpsys deviceidle enable >/dev/null 2>&1
    dumpsys deviceidle force-idle >/dev/null 2>&1
    ;;
  *)
    dumpsys deviceidle unforce >/dev/null 2>&1
    ;;
esac
exit 0
