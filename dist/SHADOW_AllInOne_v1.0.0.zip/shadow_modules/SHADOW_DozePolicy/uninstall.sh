#!/system/bin/sh
# uninstall SHADOW_DozePolicy
SHADOW_MOD=SHADOW_DozePolicy
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
