#!/system/bin/sh
# Action button for SHADOW_DozePolicy (Shadow Doze Policy)
SHADOW_MOD=SHADOW_DozePolicy
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DozePolicy/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Doze Policy"
echo " Profile aware Doze control: Doze stays out of the way while you game, and is pushed back to its most aggressive state on the battery profile."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_DozePolicy/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_DozePolicy"
  echo " enable  : ksud module enable SHADOW_DozePolicy"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
