#!/system/bin/sh
# ===================================================================
#  Shadow App Standby Killer
#  Moves every installed app out of the rarely used bucket so Android never freezes your apps in the background.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_AppStandbyKill
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AppStandbyKill/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AppStandbyKill/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
exit 0
