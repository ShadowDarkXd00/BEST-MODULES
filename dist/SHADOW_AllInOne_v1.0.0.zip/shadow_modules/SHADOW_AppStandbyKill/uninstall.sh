#!/system/bin/sh
# uninstall SHADOW_AppStandbyKill
SHADOW_MOD=SHADOW_AppStandbyKill
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
