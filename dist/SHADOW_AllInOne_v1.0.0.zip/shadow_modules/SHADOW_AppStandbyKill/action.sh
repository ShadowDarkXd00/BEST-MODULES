#!/system/bin/sh
# Action button for SHADOW_AppStandbyKill (Shadow App Standby Killer)
SHADOW_MOD=SHADOW_AppStandbyKill
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AppStandbyKill/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow App Standby Killer"
echo " Moves every installed app out of the rarely used bucket so Android never freezes your apps in the background."
echo "-----------------------------------------------"
echo " group    : Battery"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_AppStandbyKill/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_AppStandbyKill"
  echo " enable  : ksud module enable SHADOW_AppStandbyKill"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
