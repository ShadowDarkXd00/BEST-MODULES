#!/system/bin/sh
# ===================================================================
#  Shadow App Standby Killer  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_AppStandbyKill
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AppStandbyKill/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AppStandbyKill/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
for p in $(spackages); do sstandby_active "$p"; done
ssettings global app_standby_enabled 0
slog "app standby bucket cleared for every package"
exit 0
