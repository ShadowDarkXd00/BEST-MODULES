#!/system/bin/sh
# Action button for SHADOW_AdBlockHosts (Shadow Ad Blocker)
SHADOW_MOD=SHADOW_AdBlockHosts
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AdBlockHosts/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Ad Blocker"
echo " Blocks advertising and tracking domains system wide by mounting a clean hosts file over the system one. The original file is restored the moment the module is removed."
echo "-----------------------------------------------"
echo " group    : Network"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_AdBlockHosts/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_AdBlockHosts"
  echo " enable  : ksud module enable SHADOW_AdBlockHosts"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
