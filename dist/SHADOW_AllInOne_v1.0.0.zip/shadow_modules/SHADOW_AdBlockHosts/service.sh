#!/system/bin/sh
# ===================================================================
#  Shadow Ad Blocker  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_AdBlockHosts
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AdBlockHosts/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AdBlockHosts/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
mount -o bind /data/adb/shadow/hosts /system/etc/hosts 2>/dev/null || true
exit 0
