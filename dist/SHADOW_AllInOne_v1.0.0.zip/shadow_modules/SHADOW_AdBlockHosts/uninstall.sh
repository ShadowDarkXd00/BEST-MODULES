#!/system/bin/sh
# uninstall SHADOW_AdBlockHosts
SHADOW_MOD=SHADOW_AdBlockHosts
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"
umount /system/etc/hosts 2>/dev/null
rm -f /data/adb/shadow/hosts
exit 0
