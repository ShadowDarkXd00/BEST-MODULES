#!/system/bin/sh
# ===================================================================
#  Shadow Ad Blocker
#  Blocks advertising and tracking domains system wide by mounting a clean hosts file over the system one. The original file is restored the moment the module is removed.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_AdBlockHosts
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AdBlockHosts/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_AdBlockHosts/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
mkdir -p /data/adb/shadow
if [ ! -f /data/adb/shadow/hosts ]; then
  cat > /data/adb/shadow/hosts <<'SHADOW_HOSTS_EOF'
127.0.0.1 doubleclick.net
127.0.0.1 googlesyndication.com
127.0.0.1 googleadservices.com
127.0.0.1 adservice.google.com
127.0.0.1 pagead2.googlesyndication.com
127.0.0.1 ads.yahoo.com
127.0.0.1 adnxs.com
127.0.0.1 taboola.com
127.0.0.1 outbrain.com
127.0.0.1 criteo.com
127.0.0.1 amplitude.com
127.0.0.1 app-measurement.com
127.0.0.1 branch.io
127.0.0.1 adjust.com
127.0.0.1 appsflyer.com
SHADOW_HOSTS_EOF
fi
( sleep 20; mount -o bind /data/adb/shadow/hosts /system/etc/hosts 2>/dev/null ) >/dev/null 2>&1 &
slog "ad blocker hosts file prepared"
exit 0
