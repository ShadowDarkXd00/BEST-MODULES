#!/system/bin/sh
# ---------------------------------------------------------------
#  Shadow Ad Blocker
#  part of the SHADOW module suite for Poco M2 Pro (beryllium)
# ---------------------------------------------------------------
SKIPUNZIP=0
ui_print " "
ui_print "  Shadow Ad Blocker"
ui_print "  group    : Network"
ui_print "  profiles : gaming,performance,balanced,battery"
ui_print "  device   : $(getprop ro.product.model) / $(getprop ro.product.device)"
ui_print " "
# keep the module scripts executable
for f in "$MODPATH"/*.sh; do
  [ -f "$f" ] && chmod 0755 "$f"
done
chmod 0644 "$MODPATH/module.prop" 2>/dev/null
[ -f "$MODPATH/system.prop" ] && chmod 0644 "$MODPATH/system.prop"
