#!/system/bin/sh
# Action button for SHADOW_CoolMode (Shadow Cool Mode)
SHADOW_MOD=SHADOW_CoolMode
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CoolMode/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Cool Mode"
echo " Cool mode profile: keeps the skin temperature ceiling low, perfect for long sessions and for charging while gaming."
echo "-----------------------------------------------"
echo " group    : Thermal"
echo " profiles : battery,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_CoolMode/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CoolMode"
  echo " enable  : ksud module enable SHADOW_CoolMode"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
