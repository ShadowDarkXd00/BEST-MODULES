#!/system/bin/sh
# ===================================================================
#  Shadow Cool Mode
#  Cool mode profile: keeps the skin temperature ceiling low, perfect for long sessions and for charging while gaming.
#  profile: battery,balanced
# ===================================================================
SHADOW_MOD=SHADOW_CoolMode
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CoolMode/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CoolMode/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sthermal_raise 'skin|battery|shell|case' 42000
slog "cool mode active"
exit 0
