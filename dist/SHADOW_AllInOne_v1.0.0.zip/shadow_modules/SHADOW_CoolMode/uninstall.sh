#!/system/bin/sh
# uninstall SHADOW_CoolMode
SHADOW_MOD=SHADOW_CoolMode
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
