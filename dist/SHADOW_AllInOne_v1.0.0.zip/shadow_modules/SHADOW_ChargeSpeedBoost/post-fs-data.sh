#!/system/bin/sh
# ===================================================================
#  Shadow Charge Speed Boost
#  Asks the charger subsystem for maximum power by lifting the USB power source current limit and the charge pump frequency.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_ChargeSpeedBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeSpeedBoost/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeSpeedBoost/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
sfile /sys/class/power_supply/usb/current_max 3000
sfile /sys/class/power_supply/ac/current_max 3000
sfile /sys/class/thermal/thermal_zone0/trip_point_0_temp 55000
scharge_set_current 3000
exit 0
