#!/system/bin/sh
# uninstall SHADOW_ChargeSpeedBoost
SHADOW_MOD=SHADOW_ChargeSpeedBoost
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
