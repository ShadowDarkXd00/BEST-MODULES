#!/system/bin/sh
# Action button for SHADOW_ChargeSpeedBoost (Shadow Charge Speed Boost)
SHADOW_MOD=SHADOW_ChargeSpeedBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeSpeedBoost/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Charge Speed Boost"
echo " Asks the charger subsystem for maximum power by lifting the USB power source current limit and the charge pump frequency."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeSpeedBoost/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeSpeedBoost"
  echo " enable  : ksud module enable SHADOW_ChargeSpeedBoost"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
