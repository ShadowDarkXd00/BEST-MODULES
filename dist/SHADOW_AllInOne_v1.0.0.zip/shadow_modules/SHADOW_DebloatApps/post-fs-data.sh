#!/system/bin/sh
# ===================================================================
#  Shadow Debloat Apps
#  Disables the bloat that custom ROMs still ship, like the stock browser, the stock mail client and the face editor. Everything is restored the moment the module is removed.
#  profile: gaming,performance,balanced,battery
# ===================================================================
SHADOW_MOD=SHADOW_DebloatApps
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DebloatApps/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DebloatApps/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for p in com.android.browser com.android.email com.android.faceeditor com.android.wallpaper.holospiral com.android.dreams.basic; do
  pm path $p >/dev/null 2>&1 || continue
  pm disable-user --user 0 $p >/dev/null 2>&1 && slog "debloat: disabled $p"
done
exit 0
