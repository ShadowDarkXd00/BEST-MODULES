#!/system/bin/sh
# Action button for SHADOW_DebloatApps (Shadow Debloat Apps)
SHADOW_MOD=SHADOW_DebloatApps
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DebloatApps/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Debloat Apps"
echo " Disables the bloat that custom ROMs still ship, like the stock browser, the stock mail client and the face editor. Everything is restored the moment the module is removed."
echo "-----------------------------------------------"
echo " group    : Privacy"
echo " profiles : gaming,performance,balanced,battery"
echo " status   : $([ -f /data/adb/modules/SHADOW_DebloatApps/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_DebloatApps"
  echo " enable  : ksud module enable SHADOW_DebloatApps"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
