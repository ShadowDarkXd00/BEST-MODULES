#!/system/bin/sh
# ===================================================================
#  Shadow Debloat Apps  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_DebloatApps
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_DebloatApps/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_DebloatApps/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
exit 0
