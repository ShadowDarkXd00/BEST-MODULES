#!/system/bin/sh
# uninstall SHADOW_DebloatApps
SHADOW_MOD=SHADOW_DebloatApps
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"
for p in com.android.browser com.android.email com.android.faceeditor com.android.wallpaper.holospiral com.android.dreams.basic; do
  pm enable $p >/dev/null 2>&1
done
exit 0
