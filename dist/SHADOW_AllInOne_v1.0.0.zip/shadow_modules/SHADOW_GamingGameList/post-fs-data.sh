#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Game Whitelist
#  Keeps your installed games in memory: protects popular game packages from Doze, the app standby bucket and the low memory killer.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GamingGameList
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingGameList/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingGameList/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
exit 0
