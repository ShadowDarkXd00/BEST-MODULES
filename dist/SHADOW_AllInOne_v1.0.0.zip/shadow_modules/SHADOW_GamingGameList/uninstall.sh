#!/system/bin/sh
# uninstall SHADOW_GamingGameList
SHADOW_MOD=SHADOW_GamingGameList
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
