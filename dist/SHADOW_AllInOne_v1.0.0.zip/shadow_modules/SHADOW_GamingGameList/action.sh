#!/system/bin/sh
# Action button for SHADOW_GamingGameList (Shadow Gaming Game Whitelist)
SHADOW_MOD=SHADOW_GamingGameList
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingGameList/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming Game Whitelist"
echo " Keeps your installed games in memory: protects popular game packages from Doze, the app standby bucket and the low memory killer."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingGameList/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingGameList"
  echo " enable  : ksud module enable SHADOW_GamingGameList"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
