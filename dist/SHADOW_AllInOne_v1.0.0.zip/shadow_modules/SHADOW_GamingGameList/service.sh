#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Game Whitelist  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GamingGameList
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingGameList/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingGameList/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
for p in $(pm list packages 2>/dev/null | sed 's/^package://'); do
  case "$p" in
    com.miHoYo*|com.hypergryph*|com.riotgames*|com.tencent*|com.netease*|com.supercell*|com.activision*|com.ea.gp.*|com.garena*|com.mojang*|com.rockstargames*|com.krafton*|com.pubg*|com.unity*|com.brawl*|com.dxco*|com.madfingergames*|com.snapchat*|com.garena.game.*)
      sdeviceidle_whitelist "$p"
      sstandby_active "$p"
      sappop_allow "$p" RUN_IN_BACKGROUND
      sappop_allow "$p" RUN_ANY_IN_BACKGROUND
      slog "game protected: $p" ;;
  esac
done
exit 0
