#!/system/bin/sh
# Action button for SHADOW_GamingBackgroundKiller (Shadow Gaming Background Killer)
SHADOW_MOD=SHADOW_GamingBackgroundKiller
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingBackgroundKiller/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Gaming Background Killer"
echo " Clears cached background processes so the whole RAM is available to the game. Run it right before you start a match from the action button."
echo "-----------------------------------------------"
echo " group    : Gaming"
echo " profiles : gaming,performance"
echo " status   : $([ -f /data/adb/modules/SHADOW_GamingBackgroundKiller/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_GamingBackgroundKiller"
  echo " enable  : ksud module enable SHADOW_GamingBackgroundKiller"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
