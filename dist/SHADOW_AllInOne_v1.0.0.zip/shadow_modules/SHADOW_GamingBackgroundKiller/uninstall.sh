#!/system/bin/sh
# uninstall SHADOW_GamingBackgroundKiller
SHADOW_MOD=SHADOW_GamingBackgroundKiller
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
