#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Background Killer  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_GamingBackgroundKiller
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingBackgroundKiller/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingBackgroundKiller/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
am kill-all 2>/dev/null
pm trim-caches 256M 2>/dev/null
slog "background processes cleared for gaming"
exit 0
