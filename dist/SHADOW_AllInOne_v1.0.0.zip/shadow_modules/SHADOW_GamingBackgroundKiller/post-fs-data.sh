#!/system/bin/sh
# ===================================================================
#  Shadow Gaming Background Killer
#  Clears cached background processes so the whole RAM is available to the game. Run it right before you start a match from the action button.
#  profile: gaming,performance
# ===================================================================
SHADOW_MOD=SHADOW_GamingBackgroundKiller
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_GamingBackgroundKiller/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_GamingBackgroundKiller/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
exit 0
