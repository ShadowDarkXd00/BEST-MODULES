#!/system/bin/sh
# Action button for SHADOW_ChargeSmartCharge (Shadow Smart Charge)
SHADOW_MOD=SHADOW_ChargeSmartCharge
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeSmartCharge/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow Smart Charge"
echo " Adaptive charging: full speed below 70 percent, then a gentle taper to the last 30 percent so the battery is not stressed at the top of the curve."
echo "-----------------------------------------------"
echo " group    : Charge"
echo " profiles : gaming,performance,balanced"
echo " status   : $([ -f /data/adb/modules/SHADOW_ChargeSmartCharge/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_ChargeSmartCharge"
  echo " enable  : ksud module enable SHADOW_ChargeSmartCharge"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
