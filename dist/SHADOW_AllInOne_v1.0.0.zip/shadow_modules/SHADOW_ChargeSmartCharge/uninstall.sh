#!/system/bin/sh
# uninstall SHADOW_ChargeSmartCharge
SHADOW_MOD=SHADOW_ChargeSmartCharge
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
