#!/system/bin/sh
# ===================================================================
#  Shadow Smart Charge  (late start service)
# ===================================================================
SHADOW_MOD=SHADOW_ChargeSmartCharge
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeSmartCharge/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeSmartCharge/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
swait_boot 120
_lvl=$(sbattery_level)
case "$_lvl" in
  ''|*[!0-9]*) : ;;
  8[0-9]|9[0-9]|100) scharge_set_current 1500 ;;
  *) scharge_set_current 3000 ;;
esac
exit 0
