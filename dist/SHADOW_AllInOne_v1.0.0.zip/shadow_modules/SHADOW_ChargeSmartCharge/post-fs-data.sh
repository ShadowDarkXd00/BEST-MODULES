#!/system/bin/sh
# ===================================================================
#  Shadow Smart Charge
#  Adaptive charging: full speed below 70 percent, then a gentle taper to the last 30 percent so the battery is not stressed at the top of the curve.
#  profile: gaming,performance,balanced
# ===================================================================
SHADOW_MOD=SHADOW_ChargeSmartCharge
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_ChargeSmartCharge/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_ChargeSmartCharge/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scharge_set_current 3000
_lvl=$(sbattery_level)
case "$_lvl" in ''|*[!0-9]*) : ;;
  8[0-9]|9[0-9]|100) scharge_set_current 1500 ;;
esac
exit 0
