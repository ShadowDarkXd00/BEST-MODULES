#!/system/bin/sh
# ===================================================================
#  Shadow CPU Scheduler Features
#  Trims scheduler features that add latency without any visible benefit on a modern kernel.
#  profile: performance,gaming
# ===================================================================
SHADOW_MOD=SHADOW_CPUSchedFeatures
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUSchedFeatures/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUSchedFeatures/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for p in $(scpu_policies); do sfile "$p/sched_boost" 1; done
ssysctl kernel.sched_child_runs_first 1
exit 0
