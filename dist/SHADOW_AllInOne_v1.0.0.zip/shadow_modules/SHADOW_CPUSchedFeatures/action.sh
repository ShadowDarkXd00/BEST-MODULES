#!/system/bin/sh
# Action button for SHADOW_CPUSchedFeatures (Shadow CPU Scheduler Features)
SHADOW_MOD=SHADOW_CPUSchedFeatures
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUSchedFeatures/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Scheduler Features"
echo " Trims scheduler features that add latency without any visible benefit on a modern kernel."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : performance,gaming"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUSchedFeatures/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUSchedFeatures"
  echo " enable  : ksud module enable SHADOW_CPUSchedFeatures"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
