#!/system/bin/sh
# uninstall SHADOW_CPUSchedFeatures
SHADOW_MOD=SHADOW_CPUSchedFeatures
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
