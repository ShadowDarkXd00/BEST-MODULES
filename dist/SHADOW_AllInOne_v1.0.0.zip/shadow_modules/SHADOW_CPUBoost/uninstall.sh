#!/system/bin/sh
# uninstall SHADOW_CPUBoost
SHADOW_MOD=SHADOW_CPUBoost
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
