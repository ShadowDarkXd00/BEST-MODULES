#!/system/bin/sh
# Action button for SHADOW_CPUBoost (Shadow CPU Boost)
SHADOW_MOD=SHADOW_CPUBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUBoost/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Boost"
echo " Global CPU boost: performance governor plus a hard frequency lock on every cluster for maximum sustained throughput."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : performance,gaming"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUBoost/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUBoost"
  echo " enable  : ksud module enable SHADOW_CPUBoost"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
