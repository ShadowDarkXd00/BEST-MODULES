#!/system/bin/sh
# ===================================================================
#  Shadow CPU Boost
#  Global CPU boost: performance governor plus a hard frequency lock on every cluster for maximum sustained throughput.
#  profile: performance,gaming
# ===================================================================
SHADOW_MOD=SHADOW_CPUBoost
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUBoost/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUBoost/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
scpu_set_gov performance
scpu_boost_lock
exit 0
