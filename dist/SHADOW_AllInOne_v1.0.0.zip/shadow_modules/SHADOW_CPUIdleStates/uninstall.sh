#!/system/bin/sh
# uninstall SHADOW_CPUIdleStates
SHADOW_MOD=SHADOW_CPUIdleStates
[ -f /data/adb/shadow/lib.sh ] && . /data/adb/shadow/lib.sh
slog "uninstall requested for $SHADOW_MOD"

exit 0
