#!/system/bin/sh
# ===================================================================
#  Shadow CPU Idle States
#  Trims the deep C-states and the cpuidle disable switch so the SoC reacts instantly instead of sleeping for milliseconds.
#  profile: performance,gaming
# ===================================================================
SHADOW_MOD=SHADOW_CPUIdleStates
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUIdleStates/lib.sh 2>/dev/null || . /data/adb/modules_update/SHADOW_CPUIdleStates/lib.sh 2>/dev/null
fi
sprofile_gate "$SHADOW_MOD" || exit 0
for s in /sys/devices/system/cpu/cpu[0-9]*/cpuidle/state*; do
  [ -e "$s/disable" ] && sfile "$s/disable" 1
done
sfile /sys/devices/system/cpu/cpuidle/current_state_entered 0
exit 0
