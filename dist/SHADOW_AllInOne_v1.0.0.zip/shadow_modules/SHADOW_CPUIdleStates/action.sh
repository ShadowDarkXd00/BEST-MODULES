#!/system/bin/sh
# Action button for SHADOW_CPUIdleStates (Shadow CPU Idle States)
SHADOW_MOD=SHADOW_CPUIdleStates
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_CPUIdleStates/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " Shadow CPU Idle States"
echo " Trims the deep C-states and the cpuidle disable switch so the SoC reacts instantly instead of sleeping for milliseconds."
echo "-----------------------------------------------"
echo " group    : Performance"
echo " profiles : performance,gaming"
echo " status   : $([ -f /data/adb/modules/SHADOW_CPUIdleStates/disable ] && echo DISABLED || echo ENABLED)"
echo "-----------------------------------------------"
if command -v ksud >/dev/null 2>&1; then
  echo " disable : ksud module disable SHADOW_CPUIdleStates"
  echo " enable  : ksud module enable SHADOW_CPUIdleStates"
fi
echo " log     : /data/adb/shadow/shadow.log"
echo "==============================================="
