#!/system/bin/sh
# ===================================================================
#  SHADOW ALL IN ONE  -  installer
#  146 modules for Poco M2 Pro (beryllium)
# ===================================================================
SKIPUNZIP=0
MODID=SHADOW_AllInOne
SHADOW_DIR=/data/adb/shadow
DEF_PROFILE=gaming

ui_print " "
ui_print "  ======================================================"
ui_print "    S H A D O W   A L L   I N   O N E"
ui_print "    146 modules  |  Poco M2 Pro (beryllium)"
ui_print "  ======================================================"
ui_print " "

SRC=""
for d in "$MODPATH" /data/adb/modules_update/$MODID /data/adb/modules/$MODID; do
  if [ -d "$d/shadow_modules" ]; then SRC="$d"; break; fi
done
if [ -z "$SRC" ]; then
  ui_print "! module payload not found - aborting"
  exit 1
fi

mkdir -p "$SHADOW_DIR" "$SHADOW_DIR/profiles"

# runtime library + control script
cp -f "$SRC/lib.sh" "$SHADOW_DIR/lib.sh" 2>/dev/null
chmod 0755 "$SHADOW_DIR/lib.sh" 2>/dev/null
cp -f "$SRC/control.sh" "$SHADOW_DIR/control.sh" 2>/dev/null
chmod 0755 "$SHADOW_DIR/control.sh" 2>/dev/null

# ---------------------------------------------------------------
#  install every module
# ---------------------------------------------------------------
COUNT=0
rm -f "$SHADOW_DIR/module_index" 2>/dev/null
for d in "$SRC/shadow_modules"/*/; do
  [ -d "$d" ] || continue
  id=$(basename "$d")
  case "$id" in SHADOW_*) ;; *) continue ;; esac
  rm -rf "/data/adb/modules/$id" 2>/dev/null
  mkdir -p "/data/adb/modules/$id" 2>/dev/null
  cp -af "$d/." "/data/adb/modules/$id/" 2>/dev/null
  chmod 0755 "/data/adb/modules/$id"/*.sh 2>/dev/null
  chmod 0644 "/data/adb/modules/$id/module.prop" 2>/dev/null
  chmod 0644 "/data/adb/modules/$id/system.prop" 2>/dev/null
  prof=$(grep '^shadowProfiles=' "/data/adb/modules/$id/module.prop" 2>/dev/null | cut -d= -f2-)
  echo "$id|$prof" >> "$SHADOW_DIR/module_index"
  COUNT=$((COUNT + 1))
done

# ---------------------------------------------------------------
#  build the profile maps
# ---------------------------------------------------------------
rm -f "$SHADOW_DIR/profiles"/* 2>/dev/null
for p in gaming performance balanced battery; do
  : > "$SHADOW_DIR/profiles/$p"
done
while IFS='|' read -r id prof; do
  [ -z "$id" ] && continue
  for p in $(echo "$prof" | tr ',' ' '); do
    [ -z "$p" ] && continue
    echo "$id" >> "$SHADOW_DIR/profiles/$p"
  done
done < "$SHADOW_DIR/module_index"

cat > "$SHADOW_DIR/always_on" <<'SHADOW_ALWAYS_EOF'
SHADOW_AllInOne
SHADOW_UltraBatteryBackup
SHADOW_DozeKiller
SHADOW_AppStandbyKill
SHADOW_BackgroundFreeze
SHADOW_ProfileManager
SHADOW_ControlCenter
SHADOW_BootLoopGuard
SHADOW_ALWAYS_EOF

echo "$DEF_PROFILE" > "$SHADOW_DIR/profile"

# ---------------------------------------------------------------
#  enable the modules that belong to the active profile
# ---------------------------------------------------------------
for d in /data/adb/modules/SHADOW_*/; do
  [ -d "$d" ] || continue
  id=$(basename "$d")
  if grep -qx "$id" "$SHADOW_DIR/profiles/$DEF_PROFILE" 2>/dev/null || \
     grep -qx "$id" "$SHADOW_DIR/always_on" 2>/dev/null; then
    rm -f "$d/disable" 2>/dev/null
  else
    touch "$d/disable" 2>/dev/null
  fi
done

ui_print " - installed : $COUNT Shadow modules"
ui_print " - profile   : $DEF_PROFILE"
ui_print " - switch    : sh /data/adb/shadow/control.sh profile battery"
ui_print " - logs      : /data/adb/shadow/shadow.log"
ui_print " "
ui_print " REBOOT to activate the suite."
