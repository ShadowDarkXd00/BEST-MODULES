#!/system/bin/sh
# ===================================================================
#  SHADOW control script
#  usage: sh /data/adb/shadow/control.sh <command> [argument]
# ===================================================================
SHADOW_DIR=/data/adb/shadow
[ -f "$SHADOW_DIR/lib.sh" ] && . "$SHADOW_DIR/lib.sh"

usage() {
  echo "-----------------------------------------------"
  echo " profile <gaming|performance|balanced|battery>"
  echo " status"
  echo " enable  <module id>"
  echo " disable <module id>"
  echo " kill    <package name>"
  echo " governor <performance|schedutil|powersave>"
  echo " logs"
  echo " clean"
  echo "-----------------------------------------------"
}

case "$1" in
  profile)
    p="$2"
    case "$p" in
      gaming|performance|balanced|battery) ;;
      *) echo "unknown profile"; usage; exit 1 ;;
    esac
    echo "$p" > "$SHADOW_DIR/profile"
    for d in /data/adb/modules/SHADOW_*/; do
      [ -d "$d" ] || continue
      id=$(basename "$d")
      if grep -qx "$id" "$SHADOW_DIR/profiles/$p" 2>/dev/null || \
         grep -qx "$id" "$SHADOW_DIR/always_on" 2>/dev/null; then
        rm -f "$d/disable"
      else
        touch "$d/disable"
      fi
    done
    echo "profile set to $p - reboot to apply"
    ;;
  status)
    echo "profile   : $(sprofile)"
    echo "modules   : $(ls -1 /data/adb/modules 2>/dev/null | grep -c SHADOW_)"
    echo "battery   : $(sbattery_level)%  $(scharge_voltage_now) mV  $(scharge_current_now) mA"
    echo "cpu       : $(scpu_governors | tr '\n' ' ')"
    echo "gpu       : $(sgpu_busy)% busy"
    echo "memory    : $(grep MemAvailable /proc/meminfo 2>/dev/null)"
    ;;
  enable)
    rm -f "/data/adb/modules/$2/disable"; echo "$2 enabled" ;;
  disable)
    touch "/data/adb/modules/$2/disable"; echo "$2 disabled" ;;
  kill)
    am force-stop "$2" 2>/dev/null; echo "$2 killed" ;;
  governor)
    scpu_set_gov "$2"; echo "governor set to $2" ;;
  logs)
    tail -n 60 "$SHADOW_DIR/shadow.log" 2>/dev/null ;;
  clean)
    cmd package trim-caches 2G >/dev/null 2>&1
    rm -f "$SHADOW_DIR"/*.log 2>/dev/null
    echo "caches and logs cleaned" ;;
  *)
    usage ;;
esac
