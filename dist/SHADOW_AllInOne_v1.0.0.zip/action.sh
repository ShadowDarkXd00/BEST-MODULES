#!/system/bin/sh
SHADOW_MOD=SHADOW_AllInOne
if [ -f /data/adb/shadow/lib.sh ]; then
  . /data/adb/shadow/lib.sh
else
  . /data/adb/modules/SHADOW_AllInOne/lib.sh 2>/dev/null
fi
echo "==============================================="
echo " SHADOW ALL IN ONE"
echo " profile  : $(sprofile)"
echo " modules  : $(ls -1 /data/adb/modules 2>/dev/null | grep -c SHADOW_) installed"
echo " battery  : $(sbattery_level)%  $(scharge_voltage_now) mV"
echo "-----------------------------------------------"
echo " switch profile : sh /data/adb/shadow/control.sh profile gaming|performance|balanced|battery"
echo " status         : sh /data/adb/shadow/control.sh status"
echo " logs           : sh /data/adb/shadow/control.sh logs"
echo "==============================================="
